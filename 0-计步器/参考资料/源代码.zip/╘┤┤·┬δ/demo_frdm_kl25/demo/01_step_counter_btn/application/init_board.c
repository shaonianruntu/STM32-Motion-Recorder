/* init_board.c */

#include "app_inc.h"

/* UART0. */
const uart_config_t UartConfigStruct0 = 
{
    BSP_CORE_CLK_HZ,
    BSP_UART_DEBUG_BAUDRATE
};

/* I2C0. */
const i2c_config_t I2cConfigStruct0 =
{
    BSP_BUS_CLK_HZ,
    BSP_AXS_I2C_BAUDRATE,
};

/* Systick. */
const systick_config_t SystickConfigStruct0 =
{
    BSP_CORE_CLK_HZ,
    200U, /* TicksPerSecond */ /* 5ms per tick. */
};

void init_board(void)
{
    init_io();
    init_io_uart();
    init_io_i2c();
    init_io_ili9163();
    init_io_buttons();
    
    /* Initialize the debug UART. */
    UART0_Init(&UartConfigStruct0);
    /* Initialize the I2C. */
    I2C_Init(BSP_AXS_I2C_INSTANCE, &I2cConfigStruct0);
    /* Install the LCD. */
    ILI9163_Install(&MyLcdIOStruct);
    TShell_Install(TSHELL0, &mTshellApiStruct0);
    
    /* Initialize the Systick. */
    SYSTICK_Init(&SystickConfigStruct0);
}

/******************************************************************************
* Internal Functions.
******************************************************************************/
int fputc(int c, FILE *f)
{
    UART0_PutChar((uint8_t)c);
    return c;
}

int fgetc(FILE *f)
{
    return (UART0_GetChar());
}
