/* app_inc.h */
#ifndef __APP_INC_H__
#define __APP_INC_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "init_io.h"

#include "fsl_uart.h"
#include "fsl_gpio.h"
#include "fsl_i2c.h"
#include "arm_systick.h"

#include "mma8451.h"
#include "ili9163.h" /* lcd module. */
#include "config.h"  /* zlggui. */
#include "tshell.h"  /* tshell. */

#define TSHELL0    (0U)

extern const ili9163_gpio_io_t MyLcdIOStruct;
extern const tshell_api_t mTshellApiStruct0;

void init_board(void);

#endif /* __APP_INC_H__ */

