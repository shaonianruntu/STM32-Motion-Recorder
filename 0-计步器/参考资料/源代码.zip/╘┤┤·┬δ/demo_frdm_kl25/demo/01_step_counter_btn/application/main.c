/* main.c */

#include "app_inc.h"
#include "MKL25Z4.h"

static mma8451_position_t MyAcclPosStruct;
static uint32_t gTickCounterForMMA8451 = 0U;
volatile bool bFlagForMMA8451 = false;

#define SAMPLE_POINT_COUNT          100//200
#define SAMPLE_BUFFER_GROUP_COUNT   2
#define SAMPLE_POINT_PER_GROUP      (SAMPLE_POINT_COUNT/SAMPLE_BUFFER_GROUP_COUNT)
#define SAMPLE_AVERAGE_COUNT        4
#define SAMPLE_ACC_COUNT            3
#define SAMPLE_POINT_IN_TICKS       4

#define ERROR_EVERYTHING_IS_OK      0
#define ERROR_SAMPLE_OVERFLOW       1

#define DETECTOR_MIN_PPValue  (3000)//(10000)

#define DETECTOR_MAX_Value  (32767)
#define DETECTOR_MIN_Value  (-32768)

uint32_t gErrorCode = 0U;

/* Sample value. */
int16_t gSampleAccValue[SAMPLE_ACC_COUNT][SAMPLE_POINT_COUNT]; /* sample values. */
uint32_t gSampleIndex = 0U;
bool gSampleGroupWritable[SAMPLE_BUFFER_GROUP_COUNT];
uint32_t gSampleGroupIndex;

/* Peak to Peak value. */
int16_t gSampleValueMax[SAMPLE_ACC_COUNT];
int16_t gSampleValueMin[SAMPLE_ACC_COUNT];

/* 检测阈值点 */
int16_t gSampleShresholdValueForDetector[SAMPLE_ACC_COUNT];
uint32_t gSampleShresholdIdxForDetector = SAMPLE_ACC_COUNT;

/* This value would be the corssing point and comparied with every sample point . */
int16_t gSamplePrePPValue;
uint32_t gSamplePrePPIndex;
uint32_t gSampleMidPPIndex;

/* Average filter. */
volatile uint32_t gFilterIndex[SAMPLE_ACC_COUNT] = {0U};
volatile int16_t gFilterBuffer[SAMPLE_ACC_COUNT][SAMPLE_AVERAGE_COUNT] = {0};

/* main进程的空闲时间计算 */
volatile uint32_t gCurTicker;
volatile uint32_t gStepCounter = 0U; /* 计步值。 */

volatile bool gBtnEventFlag[5] = {false, false, false, false, false};
bool beInManualMode = false;
uint32_t gKey4Counter = 0U;
uint32_t gKey5Counter = 0U;
#define KEY_FILTER_COUNT    (20U)


static void TickCallback(void);
static void get_btn_event(void);
static void clear_btn_event(void);

int16_t sample_average_filter(uint32_t group, int16_t val);

int main(void)
{    
    uint32_t i, ii;

    /* Init the hardware. */
    init_board();
    
    GPIO_SetPinDir(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN1, false);
    GPIO_SetPinDir(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN2, false);
    GPIO_SetPinDir(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN3, false);
    GPIO_SetPinDir(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN4, false);
    GPIO_SetPinDir(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN5, false);

    TShell_Init(TSHELL0);
    TShell_PutStr(TSHELL0, "************************\r\n");
    TShell_PutStr(TSHELL0, "Hello, Stepter.\r\n");
    TShell_PutStr(TSHELL0, "************************\r\n");
    TShell_PutStr(TSHELL0, "\r\n");
    TShell_PutStr(TSHELL0, "Key1 to reset counter.\r\n");
    TShell_PutStr(TSHELL0, "Key2 to show counter.\r\n");
    TShell_PutStr(TSHELL0, "Key3 on/off auto mode.\r\n");
    TShell_PutStr(TSHELL0, "Key4 manual step +.\r\n");
    TShell_PutStr(TSHELL0, "Key5 manual step -.\r\n");
    TShell_PutStr(TSHELL0, "\r\n");

    /* Init the process. */
    for (gSampleGroupIndex = 0U; gSampleGroupIndex < SAMPLE_BUFFER_GROUP_COUNT; gSampleGroupIndex++)
    {
        gSampleGroupWritable[gSampleGroupIndex] = true;
    }
    gSampleGroupIndex = 0U;
    gSamplePrePPValue = 0;
    gSamplePrePPIndex = 0U;
    gSampleMidPPIndex = 0U;
    gErrorCode = ERROR_EVERYTHING_IS_OK;

    

    printf("\r\nHello, FRDM-KL25 Board.\r\n");
    MMA8451_Init();
    SYSTICK_InstallCallback(TickCallback);
    
    gCurTicker = 0xFFFFFFFF;
    
    /* Start the monitor. */
    while (1)
    {
/***************************************************************************/
/* START */
/***************************************************************************/

        /* 错误检测 */
        if (ERROR_EVERYTHING_IS_OK != gErrorCode)
        {
            printf("Error: %d\r\n", gErrorCode);
            break;
        }
/* 实时响应按键的小循环， 开始 */
        /* Update the screen. */
        if (gBtnEventFlag[0]) /* Key1. */
        {
            TShell_PutStr(TSHELL0, "Counter reseted.\r\n");
        }
        if (gBtnEventFlag[1]) /* Key2. */
        {
            TShell_PutStr(TSHELL0, "Stepter: ");
            TShell_PutNum(TSHELL0, gStepCounter);
            TShell_PutStr(TSHELL0, "\r\n");
        }

        if (gBtnEventFlag[2])  /* Key3. */
        {
            beInManualMode = !beInManualMode;
            if (beInManualMode)
            {
                TShell_PutStr(TSHELL0, "In manual mode.\r\n");
            }
            else
            {
                TShell_PutStr(TSHELL0, "In auto mode.\r\n");
            }
        }
        if (beInManualMode)
        {
            if (gBtnEventFlag[3])  /* Key4. */
            {

                gKey4Counter++;
            }
            else
            {
                if (gKey4Counter >= KEY_FILTER_COUNT)
                {
                    gStepCounter++;
                    gKey4Counter = 0U;
                }
                
            }

            if (gBtnEventFlag[4])  /* Key5. */
            {
                gKey5Counter++;
            }
            else
            {
                if (gKey5Counter >= KEY_FILTER_COUNT)
                {
                    gStepCounter--;
                    gKey5Counter = 0U;
                }
            }
        }

        clear_btn_event();
        if (beInManualMode)
        {
            /* 清空已经处理过的缓冲区，转入下一个缓冲区 */
            gSampleGroupWritable[gSampleGroupIndex] = true;
            gSampleGroupIndex++;
            if (gSampleGroupIndex >= SAMPLE_BUFFER_GROUP_COUNT)
            {
                gSampleGroupIndex = 0U;
            }
            continue;
        }
/* 实时响应小循环， 结束 */
        
        if(gSampleGroupWritable[gSampleGroupIndex]) /* 缓冲区正在写入，不能处理。 */
        {
            continue;
        }
        /* 对缓冲区的数据进行处理 */
        /*
        1. 扫描缓冲区的每个采样点的三个纬度，进行均值滤波。
        2. 在上一个缓冲区中得到的峰峰值最大的维度上进行比较，得到记步数量的累加。
        3. 进行本缓冲区三个采样点峰峰值的计算，得到最大的峰峰值及其维度。
        4. 将本缓冲区最大峰峰值的维度同前一次缓冲区进行比较，若一致，则尽享交接，否则，执行滤过过程。
        */

        /* 程序设计的进程：
        1. 对采样数据进行均值滤波。
        2. 对采样数据进行峰值检测，更新下一周期判断步伐的检测阈值，包括滤波。
        3. 检测步伐，进行模式匹配。
        */

        /* 空闲时间检测，作为main函数处理完数据之后的空余时间
        这个值越大，表示在采样在下一个缓冲区填充完毕之前还可以插入更多的处理过程
        在理想情况下，用户数据处理使用0个滴答，那么空闲时间就应该是完成一个缓冲区采样之间的时间。
        但实际上，处理数据会用掉一点时间，那么空闲时间就应该是缓冲区采样时间间隔减去处理数据用掉的时间。
        */
        gCurTicker = 0xFFFFFFFF;

        /* Init the peak-to-peak value detector. */
        for (ii = 0U; ii < SAMPLE_ACC_COUNT; ii++ )
        {
            gSampleValueMax[ii] = -32767;
            gSampleValueMin[ii] = 32767;
        }

        /* 消化一个缓冲区的采样点. */
        for ( i = gSampleGroupIndex * SAMPLE_POINT_PER_GROUP;
              i < ((gSampleGroupIndex+1U) * SAMPLE_POINT_PER_GROUP);
              i++)
        {
            
            /* 分别处理三个采样轴的采样点 */
            for (ii = 0U; ii < SAMPLE_ACC_COUNT; ii++)
            {
                /* Execut the filter. */
                gSampleAccValue[ii][i] = sample_average_filter(ii, gSampleAccValue[ii][i]);
                
                /* 在上一次的采样过程中得到判决信息，用于本次判断 */
                if (gSampleShresholdIdxForDetector == ii)
                {
                    if (   (gSampleAccValue[ii][i] >= gSampleShresholdValueForDetector[ii])
                        && (gSampleAccValue[ii][i-1U] < gSampleShresholdValueForDetector[ii])  )
                    {
                        /* 穿越监测点，Bingo */
                        gStepCounter++;
                    }
                }

                /* Update the max and min value. */
                if (gSampleAccValue[ii][i] > gSampleValueMax[ii])
                {
                    gSampleValueMax[ii] = gSampleAccValue[ii][i];
                }
                if (gSampleAccValue[ii][i] < gSampleValueMin[ii])
                {
                    gSampleValueMin[ii] = gSampleAccValue[ii][i];
                }

            }

        }

        /* 清空已经处理过的缓冲区，转入下一个缓冲区 */
        gSampleGroupWritable[gSampleGroupIndex] = true;
        gSampleGroupIndex++;
        if (gSampleGroupIndex >= SAMPLE_BUFFER_GROUP_COUNT)
        {
            gSampleGroupIndex = 0U;
        }



        /* 更新判决阈值 */
        /*
        * 得到三个轴上的判决阈值，gSampleShresholdValueForDetector[ii]
        * 得到监控轴，gSampleShresholdIdxForDetector
        */
        gSampleShresholdIdxForDetector = SAMPLE_ACC_COUNT;
        int16_t max_diff = DETECTOR_MIN_Value;
        for (ii = 0U; ii < SAMPLE_ACC_COUNT; ii++)
        {
            int32_t sample_diff = gSampleValueMax[ii]-gSampleValueMin[ii];    
            if (sample_diff >= DETECTOR_MIN_PPValue)
            {
                gSampleShresholdValueForDetector[ii] = gSampleValueMax[ii] - (int16_t)(sample_diff / 4U);
                if (gSampleShresholdValueForDetector[ii] > max_diff)
                {
                    max_diff = gSampleShresholdValueForDetector[ii];
                    gSampleShresholdIdxForDetector = ii;
                }
            }
            else
            {
                gSampleShresholdValueForDetector[ii] = DETECTOR_MAX_Value;
            }
        }




        /* Display middle data. */
        printf("  %d:%d:%d    %d:%d:%d    %d:%d:%d\r\n",  
            gSampleValueMin[0], gSampleValueMax[0], gSampleValueMax[0]-gSampleValueMin[0],
            gSampleValueMin[1], gSampleValueMax[1], gSampleValueMax[1]-gSampleValueMin[1],
            gSampleValueMin[2], gSampleValueMax[2], gSampleValueMax[2]-gSampleValueMin[2]);
        printf("gSampleShresholdValueForDetector: %d  %d  %d\r\n", 
            gSampleShresholdValueForDetector[0],
            gSampleShresholdValueForDetector[1],
            gSampleShresholdValueForDetector[2]);
        printf("gSampleShresholdIdxForDetector: %d\r\n", gSampleShresholdIdxForDetector);

        printf(" gStepCounter: %d\r\n", gStepCounter);

        

        //SYSTICK_DelayTicks(20U);


        printf("Free Process time: %d tickers\r\n", 
            (SAMPLE_POINT_PER_GROUP*SAMPLE_POINT_IN_TICKS) - (0xFFFFFFFF-gCurTicker) );
/***************************************************************************/
/* END */
/***************************************************************************/

    }
}

static void TickCallback(void)
{

    get_btn_event();
    /* BTN1 clears the counter. */
    if (gBtnEventFlag[0])
    {
        gStepCounter = 0U;
        //gBtnEventFlag[0] = false;
    }

    if (gCurTicker > 0U)
    {
        gCurTicker--;
    }
    
    if (gTickCounterForMMA8451 >= SAMPLE_POINT_IN_TICKS) /* 50Hz */
    {
        gTickCounterForMMA8451 = 0U;

/***************************************************************************/
/* START */
/***************************************************************************/
        /* get the sample value. */
        MMA8451_GetPosition(&MyAcclPosStruct);
        /* update the index. */
        if (gSampleIndex >= SAMPLE_POINT_COUNT)
        {
            gSampleIndex = 0U;
        }
        /* fill the sample data into buffer. */
        if (gSampleGroupWritable[gSampleIndex / SAMPLE_POINT_PER_GROUP])
        {
            gSampleAccValue[0][gSampleIndex] = MyAcclPosStruct.rX;
            gSampleAccValue[1][gSampleIndex] = MyAcclPosStruct.rY;
            gSampleAccValue[2][gSampleIndex] = MyAcclPosStruct.rZ;
            /* 当前这个点是该缓冲区的最后一个点，填充之后关闭写使能，使main进程可以读到。 */
            if (0U == (gSampleIndex+1U)%SAMPLE_POINT_PER_GROUP ) 
            {
                gSampleGroupWritable[gSampleIndex / SAMPLE_POINT_PER_GROUP] = false; /* lock the buffer. */
            }
            gSampleIndex++;
        }
        else
        {
            //gErrorCode = ERROR_SAMPLE_OVERFLOW;
        }
/***************************************************************************/
/* END */
/***************************************************************************/
    }
    else
    {
        gTickCounterForMMA8451++;
    }
}

int16_t sample_average_filter(uint32_t group, int16_t val)
{
    int16_t sum;
    uint32_t i;
    
    /* update the buffer. */
    if (gFilterIndex[group] >= SAMPLE_AVERAGE_COUNT)
    {
        gFilterIndex[group] = 0U;
    }
    gFilterBuffer[group][gFilterIndex[group]] = val;
    gFilterIndex[group]++;

    /* accumulate the value. */
    sum = 0;
    for (i = 0U; i < SAMPLE_AVERAGE_COUNT; i++)
    {
        sum += gFilterBuffer[group][i];
    }
    return sum;
}


static void get_btn_event(void)
{
    if (!gBtnEventFlag[0] && (0U == GPIO_GetPinLogic(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN1)) )
    {
        gBtnEventFlag[0] = true;
    }
    if (!gBtnEventFlag[1] && (0U == GPIO_GetPinLogic(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN2)) )
    {
        gBtnEventFlag[1] = true;
    }
    if (!gBtnEventFlag[2] && (0U == GPIO_GetPinLogic(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN3)) )
    {
        gBtnEventFlag[2] = true;
    }
    if (!gBtnEventFlag[3] && (0U == GPIO_GetPinLogic(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN4)) )
    {
        gBtnEventFlag[3] = true;
    }
    if (!gBtnEventFlag[4] && (0U == GPIO_GetPinLogic(BSP_GPIO_BTN_PORT, BSP_GPIO_BTN_PIN5)) )
    {
        gBtnEventFlag[4] = true;
    }
}

static void clear_btn_event(void)
{
    uint32_t i;
    for (i = 0U; i < 5U; i++)
    {
        gBtnEventFlag[i] = false;
    }
}

/* EOF. */
