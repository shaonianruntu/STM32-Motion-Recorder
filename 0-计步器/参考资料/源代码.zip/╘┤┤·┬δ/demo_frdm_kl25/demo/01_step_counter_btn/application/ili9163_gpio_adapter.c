/* ili9163_gpio_adapter.c */

#include "app_inc.h"

static void m_InitPinsGPIO(void);
static void m_SetPinFunc_A0(bool enHigh);
static void m_SetPinFunc_CS(bool enHigh);
static void m_SetPinFunc_Reset(bool enHigh);
static void m_SetPinFunc_SDA(bool enHigh);
static void m_SetPinFunc_SCL(bool enHigh);
static void m_DelayMsFunc(uint32_t ms);

const ili9163_gpio_io_t MyLcdIOStruct = 
{
    m_InitPinsGPIO,
    m_SetPinFunc_A0,
    m_SetPinFunc_CS,
    m_SetPinFunc_Reset,
    m_SetPinFunc_SDA,
    m_SetPinFunc_SCL,
    m_DelayMsFunc
};

static void m_InitPinsGPIO(void)
{
    GPIO_SetPinLogic(0U, 12U, true);  /* A0  :D3 - PTA12. */
    GPIO_SetPinLogic(0U, 4U , true);  /* CS  :D4 - PTA4. */
    GPIO_SetPinLogic(0U, 5U , true);  /* RST :D5 - PTA5. */
    GPIO_SetPinLogic(2U, 8U , true);  /* SDA :D6 - PTC8. */
    GPIO_SetPinLogic(2U, 9U , true);  /* SCL :D7 - PTC9. */

    GPIO_SetPinDir(0U, 12U, true);  /* A0  :D3 - PTA12. */
    GPIO_SetPinDir(0U, 4U , true);  /* CS  :D4 - PTA4. */
    GPIO_SetPinDir(0U, 5U , true);  /* RST :D5 - PTA5. */
    GPIO_SetPinDir(2U, 8U , true);  /* SDA :D6 - PTC8. */
    GPIO_SetPinDir(2U, 9U , true);  /* SCL :D7 - PTC9. */
}

static void m_SetPinFunc_A0(bool enHigh)
{
    //GPIO_SetPinLogic(0U, 12U, enHigh);  /* A0  :D3 - PTA12. */
    GPIO_SetPinLogic(2U, 8U, enHigh);
}

static void m_SetPinFunc_CS(bool enHigh)
{
    //GPIO_SetPinLogic(0U, 4U , enHigh);  /* CS  :D4 - PTA4. */
    GPIO_SetPinLogic(0U, 12U , enHigh);
}
static void m_SetPinFunc_Reset(bool enHigh)
{
    //GPIO_SetPinLogic(0U, 5U , enHigh);  /* RST :D5 - PTA5. */
    GPIO_SetPinLogic(2U, 9U , enHigh);
}

static void m_SetPinFunc_SDA(bool enHigh)
{
    //GPIO_SetPinLogic(2U, 8U , enHigh);  /* SDA :D6 - PTC8. */
    GPIO_SetPinLogic(0U, 5U , enHigh);
}

static void m_SetPinFunc_SCL(bool enHigh)
{
    //GPIO_SetPinLogic(2U, 9U , enHigh);  /* SCL :D7 - PTC9. */
    GPIO_SetPinLogic(0U, 4U , enHigh);
}

static void m_DelayMsFunc(uint32_t ms)
{
    uint32_t i, j;
    for (i = 0U; i < ms; i++)
    {
        for (j = 0U; j < 10U; j++)
        {
            __asm("nop");
        }
    }
}

