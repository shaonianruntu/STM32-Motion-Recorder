/* tshell_adapter.c */

#include "app_inc.h"

static void mPutChar(uint16_t xStart, uint16_t yStart, uint8_t ch);
static void mInit(void);
static void mClearScreen(void);

const tshell_api_t mTshellApiStruct0 =
{
    2U, 5U,//uint16_t XStart, YStart;
    160U, 128U,//uint16_t XEnd, YEnd;
    6U, 9U,//uint16_t CharWidth, CharHeigth;
    mPutChar,//void (*PutCharFunc)(uint16_t xStart, uint16_t yStart, uint8_t ch);
    mInit,//void (*InitFunc)(void);
    mClearScreen//void (*ClearScreenFunc)(void);
};

static void mPutChar(uint16_t xStart, uint16_t yStart, uint8_t ch)
{
    GUI_PutChar(xStart, yStart, ch);
}

static void mInit(void)
{
    GUI_Initialize();
    GUI_SetColor(0xFFFFU, 0x0000U);	/* Set front color & back color. */
}

static void mClearScreen(void)
{
    GUI_ClearSCR();
}

