/* main.c */

#include "app_inc.h"

/* ISR Callback. */
static void MyTickISR(void);

int main(void)
{    
    init_board();

    printf("\r\nHello, FRDM-KL25 Board.\r\n");
    
    /* For GPIO - LEDs. */
    /* RED. */
    GPIO_SetPinLogic(BSP_LED_PORT_RED, BSP_LED_PIN_RED, true);
    GPIO_SetPinDir(BSP_LED_PORT_RED, BSP_LED_PIN_RED, true);
    /* GREEN. */
    GPIO_SetPinLogic(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN, true);
    GPIO_SetPinDir(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN, true);
    /* BLUE. */
    GPIO_SetPinLogic(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE, true);
    GPIO_SetPinDir(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE, true);
    
    /* Systick. */
    SYSTICK_InstallCallback(MyTickISR);
    
    printf("Green and Blue will be toggled in every 400ms,\r\n");
    printf("Red will be toggled in every 400 ticks.\r\n");
    
    while (1)
    {  
        DelayMs(400U);
        GPIO_TogglePinLogic(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN);
        DelayMs(400U);
        GPIO_TogglePinLogic(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE);
    }
}

static void MyTickISR(void)
{
    static uint32_t MyTickCounter = 0U;
    MyTickCounter++;
    if (MyTickCounter >= 400U)
    {
        MyTickCounter = 0U;
        GPIO_TogglePinLogic(BSP_LED_PORT_RED, BSP_LED_PIN_RED);
    }
}
