/* app_inc.h */
#ifndef __APP_INC_H__
#define __APP_INC_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "init_io.h"

#include "fsl_uart.h"
#include "fsl_gpio.h"
#include "arm_systick.h"

void init_board(void);
void DelayMs(uint32_t ms);

#endif /* __APP_INC_H__ */

