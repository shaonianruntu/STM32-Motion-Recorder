/* main.c */

#include "app_inc.h"

int main(void)
{    
    init_board();

    printf("\r\nHello, FRDM-KL25 Board.\r\n");
    
    /* For GPIO - LEDs. */
    /* RED. */
    GPIO_SetPinLogic(BSP_LED_PORT_RED, BSP_LED_PIN_RED, true);
    GPIO_SetPinDir(BSP_LED_PORT_RED, BSP_LED_PIN_RED, true);
    /* GREEN. */
    GPIO_SetPinLogic(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN, true);
    GPIO_SetPinDir(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN, true);
    /* BLUE. */
    GPIO_SetPinLogic(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE, true);
    GPIO_SetPinDir(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE, true);
    
    printf("Press any key to toggle the LED.\r\n");
    
    while (1)
    {
        getchar();
        GPIO_TogglePinLogic(BSP_LED_PORT_RED, BSP_LED_PIN_RED);
        getchar();
        GPIO_TogglePinLogic(BSP_LED_PORT_GREEN, BSP_LED_PIN_GREEN);
        getchar();
        GPIO_TogglePinLogic(BSP_LED_PORT_BLUE, BSP_LED_PIN_BLUE);
    }
}
