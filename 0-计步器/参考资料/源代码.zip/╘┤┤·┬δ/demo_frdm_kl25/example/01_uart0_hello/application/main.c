/* main.c */

#include "app_inc.h"

int main(void)
{
    int ch;
    
    init_board();

    printf("\r\nHello, FRDM-KL25 Board.\r\n");
    
    while (1)
    {
        ch = getchar();
        putchar(ch);
    }
}
