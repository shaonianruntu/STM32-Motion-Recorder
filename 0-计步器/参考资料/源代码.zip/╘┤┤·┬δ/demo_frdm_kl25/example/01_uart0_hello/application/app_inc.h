/* app_inc.h */
#ifndef __APP_INC_H__
#define __APP_INC_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "fsl_uart.h"
#include "fsl_gpio.h"

#include "init_io.h"



void init_board(void);

#endif /* __APP_INC_H__ */

