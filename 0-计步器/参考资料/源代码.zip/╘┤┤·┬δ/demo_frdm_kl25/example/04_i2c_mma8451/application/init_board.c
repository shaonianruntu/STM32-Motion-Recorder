/* init_board.c */

#include "app_inc.h"

/* UART0. */
const uart_config_t UartConfigStruct0 = 
{
    BSP_CORE_CLK_HZ,
    BSP_UART_DEBUG_BAUDRATE
};

void init_board(void)
{
    init_io();
    init_io_uart();
    init_io_i2c();
    
    /* Initialize the debug UART. */
    UART0_Init(&UartConfigStruct0);    
}

/******************************************************************************
* Internal Functions.
******************************************************************************/
int fputc(int c, FILE *f)
{
    UART0_PutChar((uint8_t)c);
    return c;
}

int fgetc(FILE *f)
{
    return (UART0_GetChar());
}
