/* main.c */

#include "app_inc.h"

/* I2C0. */
const i2c_config_t I2cConfigStruct0 =
{
    BSP_BUS_CLK_HZ,
    BSP_AXS_I2C_BAUDRATE,
};
static mma8451_position_t MyAcclPosStruct;

int main(void)
{    
    init_board();

    printf("\r\nHello, FRDM-KL25 Board.\r\n");
    
    /* Initialize the I2C. */
    I2C_Init(BSP_AXS_I2C_INSTANCE, &I2cConfigStruct0);
    
    MMA8451_Init();
    
    printf("Press any key to update the MMA8451 Position.\r\n");
    
    while (1)
    {  
        getchar();
        MMA8451_GetPosition(&MyAcclPosStruct);
        printf("MMA8451_GetPosition: X: %4d   Y: %4d   Z: %4d\r\n", 
            MyAcclPosStruct.rX, MyAcclPosStruct.rY, MyAcclPosStruct.rZ);
    }
}
