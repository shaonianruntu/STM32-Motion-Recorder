/* tshell.h */

#ifndef __TSHELL_H__
#define __TSHELL_H__

#include <stdint.h>
#include <stdbool.h>

#define TSHELL_INSTANCE_COUNT  (1U)

typedef struct
{
    uint16_t XStart, YStart;
    uint16_t XEnd, YEnd;
    uint16_t CharWidth, CharHeigth;
    void (*PutCharFunc)(uint16_t xStart, uint16_t yStart, uint8_t ch);
    void (*InitFunc)(void);
    void (*ClearScreenFunc)(void);
} tshell_api_t;

bool TShell_Install(uint32_t instance, const tshell_api_t *apiPtr);
void TShell_Init(uint32_t instance);
void TShell_PutChar(uint32_t instance, uint8_t ch);
uint16_t TShell_PutStr(uint32_t instance, uint8_t *str);
void TShell_PutNum(uint32_t instance, uint32_t num);
void TShell_PutNumAdv(uint32_t instance, uint32_t num, uint32_t bits, bool enRight);

#endif /* __TSHELL_H__ */
