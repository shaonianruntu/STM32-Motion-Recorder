/* tshell.c */

#include "tshell.h"

typedef struct
{
    const tshell_api_t *ApiPtr;
    uint16_t LineCount;
    uint16_t LineIndex;
    uint16_t CharCount;
    uint16_t CharIndex;
} tshell_context_t;

static tshell_context_t MyTShellContextStruct[TSHELL_INSTANCE_COUNT];

static void TShell_PutCharBasic(uint32_t instance, uint16_t line, uint16_t chr, uint8_t ch);

bool TShell_Install(uint32_t instance, const tshell_api_t *apiPtr)
{
    if ( (instance >= TSHELL_INSTANCE_COUNT) || (!apiPtr) )
    {
        return false;
    }
    MyTShellContextStruct[instance].ApiPtr = apiPtr;
    MyTShellContextStruct[instance].LineCount = (apiPtr->YEnd - apiPtr->YStart)/(apiPtr->CharHeigth);
    MyTShellContextStruct[instance].LineIndex = 0U;
    MyTShellContextStruct[instance].CharCount = (apiPtr->XEnd - apiPtr->XStart)/(apiPtr->CharWidth);
    MyTShellContextStruct[instance].CharIndex = 0U;
    return true;
}

void TShell_Init(uint32_t instance)
{
    (*(MyTShellContextStruct[instance].ApiPtr->InitFunc))();
    (*(MyTShellContextStruct[instance].ApiPtr->ClearScreenFunc))();
    TShell_PutCharBasic(instance, 0U, 0U, '>');
    MyTShellContextStruct[instance].CharIndex++;
}

void TShell_PutChar(uint32_t instance, uint8_t ch)
{
    if (   (ch == '\r') 
        || (MyTShellContextStruct[instance].CharIndex >= MyTShellContextStruct[instance].CharCount) )
    {
        MyTShellContextStruct[instance].CharIndex = 0U;
        MyTShellContextStruct[instance].LineIndex++;
        if (MyTShellContextStruct[instance].LineIndex >= MyTShellContextStruct[instance].LineCount)
        {
            MyTShellContextStruct[instance].LineIndex = 0U;
            (*(MyTShellContextStruct[instance].ApiPtr->ClearScreenFunc))();
        }

        TShell_PutCharBasic(instance, 
                MyTShellContextStruct[instance].LineIndex,
                MyTShellContextStruct[instance].CharIndex,
                ('\r' == ch)? '>':ch);
        MyTShellContextStruct[instance].CharIndex++;
    }
    else if (ch == '\n')
    {
        
    }
    else if (ch == 0x7F) /* backspace */
    {
        if (MyTShellContextStruct[instance].CharIndex > 0U)
        {
            MyTShellContextStruct[instance].CharIndex--;
            TShell_PutCharBasic(instance, 
                MyTShellContextStruct[instance].LineIndex,
                MyTShellContextStruct[instance].CharIndex,
                ' ');
        }
        
    }
    else
    {
        TShell_PutCharBasic(instance, 
            MyTShellContextStruct[instance].LineIndex,
            MyTShellContextStruct[instance].CharIndex,
            ch);
        (MyTShellContextStruct[instance].CharIndex)++;
    }
    
}

uint16_t TShell_PutStr(uint32_t instance, uint8_t *str)
{   
    while (*str)
    {
        TShell_PutChar(instance, *str);
        str++;
    }
    return MyTShellContextStruct[instance].LineIndex;
}

void TShell_PutNum(uint32_t instance, uint32_t num)
{
    uint8_t buff[16];
    uint8_t index = 0U;

    do
    {
        buff[index++] = num % 10U;
        num = num / 10U;
    } while (num != 0U);
      
    while (index > 0U)
    {
        TShell_PutChar(instance, '0'+buff[index-1]);
        index--;
    }
}

void TShell_PutNumAdv(uint32_t instance, uint32_t num, uint32_t bits, bool enRight)
{
    uint8_t buff[16];
    uint8_t index = 0U;

    /* 123, buf=[3, 2, 1] index = 3*/
    do
    {
        buff[index++] = num % 10U;
        num = num / 10U;
    } while (num != 0U);
    
    if (enRight)
    {
        while (bits > index)
        {
            TShell_PutChar(instance, ' ');
            bits--;
        }
        while (bits > 0U)
        {
            TShell_PutChar(instance, '0'+buff[bits-1]);
            bits--;
        }
    }
    else
    {
        //TShell_PutNum(instance, num);
        while (index > 0U)
        {
            TShell_PutChar(instance, '0'+buff[index-1]);
            index--;
            bits--;
        }
        while (bits > 0U)
        {
            TShell_PutChar(instance, ' ');
            bits--;
        }
    }
}

static void TShell_PutCharBasic(uint32_t instance, uint16_t line, uint16_t chr, uint8_t ch)
{
    (*(MyTShellContextStruct[instance].ApiPtr->PutCharFunc))(                                             
            /* xStart */
              chr * (MyTShellContextStruct[instance].ApiPtr->CharWidth)
            + (MyTShellContextStruct[instance].ApiPtr->XStart),                                                                                                
            /* yStart */                                               
              line * (MyTShellContextStruct[instance].ApiPtr->CharHeigth)
            + (MyTShellContextStruct[instance].ApiPtr->YStart),
            /* ASSIC */
               ch);
}
