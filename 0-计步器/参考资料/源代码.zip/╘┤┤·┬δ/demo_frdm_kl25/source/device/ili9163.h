/* ili9163.h */
#ifndef __ILI9163_H__
#define __ILI9163_H__

#include <stdint.h>
#include <stdbool.h>

#define ILI9163_HEIGHT_MAX    (160U)
#define ILI9163_WIDTH_MAX     (128U)

/*
+----X----> ILI9163_WIDTH_MAX
|
|
Y      SCREEN
|
|
V
ILI9163_HEIGHT_MAX
*/

#define     ILI9263_COLOR_RED       0xf800
#define     ILI9263_COLOR_GREEN     0x07e0
#define     ILI9263_COLOR_BLUE      0x001f
#define     ILI9263_COLOR_PURPLE    0xf81f
#define     ILI9263_COLOR_YELLOW    0xffe0
#define     ILI9263_COLOR_CYAN      0x07ff
#define     ILI9263_COLOR_ORANGE    0xfc08
#define     ILI9263_COLOR_BLACK     0x0000
#define     ILI9263_COLOR_WHITE     0xffff

typedef struct
{
    void (*InitPinsGPIO)(void);
    void (*SetPinFunc_A0)(bool enHigh);
    void (*SetPinFunc_CS)(bool enHigh);
    void (*SetPinFunc_Reset)(bool enHigh);
    void (*SetPinFunc_SDA)(bool enHigh);
    void (*SetPinFunc_SCL)(bool enHigh);
    void (*DelayMsFunc)(uint32_t ms);
} ili9163_gpio_io_t;

bool ILI9163_Install(const ili9163_gpio_io_t *ioCfgPtr);
void ILI9163_Init(void);
void ILI9163_SetWindow(uint8_t xs, uint8_t ys, uint8_t xe, uint8_t ye);
void ILI9163_ResetWindow(void);
void ILI9163_WriteParam8(uint8_t dat8);
void ILI9163_WriteParam16(uint16_t dat16);
void ILI9163_FillScreen(uint16_t color);
void ILI9163_SetPixel(uint8_t x, uint8_t y, uint16_t color);

#endif /* __ILI9163_H__ */
