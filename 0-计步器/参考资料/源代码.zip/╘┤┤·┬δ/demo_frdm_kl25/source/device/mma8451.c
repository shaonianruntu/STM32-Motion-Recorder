/* mma8451.c */
#include "mma8451.h"
#include "fsl_i2c.h"
#include "app_inc.h"

/*****************************************************************************/
/* MMA8451 driver using I2C on board. */
/*****************************************************************************/
void MMA8451_Init(void)
{
    uint8_t tmp8;
    
    /* Initialize the MMA8451. */
    MMA8451_WriteReg(0x0E, 0x0); /* Change the sense range to +-8g. */
                                  /* Bit1 Bit0 
                                      0    0     +-2g
                                      0    1     +-4g
                                      1    0     +-8g
                                  */
    tmp8 = MMA8451_ReadReg(0x2A);
    MMA8451_WriteReg(0x2A, tmp8 | 0x01); /* switch on to be in active mode. */
}

uint8_t MMA8451_ReadReg(uint8_t addr)
{
    uint8_t ret;
    
    I2C_ReadBytes(  BSP_AXS_I2C_INSTANCE,
                    MMA8451_I2C_ADDRESS,
                    addr,
                    &ret,
                    1U
    );
    
    return ret;
}

void MMA8451_WriteReg(uint8_t addr, uint8_t dat)
{
    I2C_WriteBytes( BSP_AXS_I2C_INSTANCE,
                    MMA8451_I2C_ADDRESS,
                    addr,
                    &dat,
                    1U
    );
}

bool MMA8451_GetPosition(mma8451_position_t *posPtr)
{
    uint8_t value[6];
    if ( MMA8451_ReadReg(0x00) & 0x08 ) /* Data Ready. */
    {
        I2C_ReadBytes(  BSP_AXS_I2C_INSTANCE,
                    MMA8451_I2C_ADDRESS,
                    0x01,  /* Start Address for result data. */
                    value,
                    6U
        );
        posPtr->rX = ((int16_t)(value[0]<<8) | value[1])>>2;
        posPtr->rY = ((int16_t)(value[2]<<8) | value[3])>>2;
        posPtr->rZ = ((int16_t)(value[4]<<8) | value[5])>>2;
    }
    return true;
}

