/* mma8451.h */

#ifndef __MMA8451_H__
#define __MMA8451_H__

#include <stdint.h>
#include <stdbool.h>

#define MMA8451_I2C_ADDRESS  (0x1D<<1)

typedef struct
{
    int16_t rX;
    int16_t rY;
    int16_t rZ;
} mma8451_position_t;

void MMA8451_Init(void);
uint8_t MMA8451_ReadReg(uint8_t addr);
void MMA8451_WriteReg(uint8_t addr, uint8_t dat);
bool MMA8451_GetPosition(mma8451_position_t *posPtr);

#endif /* __MMA8451_H__ */

