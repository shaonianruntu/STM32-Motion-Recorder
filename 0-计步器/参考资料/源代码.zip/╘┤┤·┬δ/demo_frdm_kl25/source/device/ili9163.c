/* ILI9163.c */

#include "ili9163.h"

#define ePinLevelHigh true
#define ePinLevelLow  false

const ili9163_gpio_io_t * volatile g_Ili9163IoPtr;

bool ILI9163_Install(const ili9163_gpio_io_t *ioCfgPtr)
{
    if (!ioCfgPtr)
    {
        return false;
    }
    g_Ili9163IoPtr = ioCfgPtr;
    return true;
}

/***************************************************************************/
/* Socket Functions. */
/***************************************************************************/
static void ILI9163_InitPinsGPIO(void)
{
    (*(g_Ili9163IoPtr->InitPinsGPIO))();
}

static void ILI9163_SetPin_A0(bool enHigh)
{
    (*(g_Ili9163IoPtr->SetPinFunc_A0))(enHigh);
}

static void ILI9163_SetPin_CS(bool enHigh)
{
    (*(g_Ili9163IoPtr->SetPinFunc_CS))(enHigh);
}

static void ILI9163_SetPin_Reset(bool enHigh)
{
    (*(g_Ili9163IoPtr->SetPinFunc_Reset))(enHigh);
}

static void ILI9163_SetPin_SDA(bool enHigh)
{
    (*(g_Ili9163IoPtr->SetPinFunc_SDA))(enHigh);
}

static void ILI9163_SetPin_SCL(bool enHigh)
{
    (*(g_Ili9163IoPtr->SetPinFunc_SCL))(enHigh);
}

static void ILI9163_DelayMs(uint32_t ms)
{
    (*(g_Ili9163IoPtr->DelayMsFunc))(ms);
}
/***************************************************************************/
/***************************************************************************/

/***************************************************************************/
/* Internal Functions. */
/***************************************************************************/

static void ILI9163_WriteCmd(uint8_t cmd)
{
    uint8_t i;

    ILI9163_SetPin_A0(ePinLevelLow); /* Cmd. */
    ILI9163_SetPin_CS(ePinLevelLow); /* Get the bus. */

    for (i = 0U; i < 8U; i++)
    {
        ILI9163_SetPin_SCL(ePinLevelLow);
        if (0U != (cmd & (1U<<(7U-i))))
        {
            ILI9163_SetPin_SDA(ePinLevelHigh);
        }
        else
        {
            ILI9163_SetPin_SDA(ePinLevelLow);
        }
        ILI9163_SetPin_SCL(ePinLevelHigh);
    }

    ILI9163_SetPin_CS(ePinLevelHigh); /* Release the bus. */
}

void ILI9163_WriteParam8(uint8_t dat8)
{
    uint8_t i;

    ILI9163_SetPin_A0(ePinLevelHigh); /* Date. */
    ILI9163_SetPin_CS(ePinLevelLow); /* Get the bus. */

    for (i = 0U; i < 8U; i++)
    {
        ILI9163_SetPin_SCL(ePinLevelLow);
        if (0U != (dat8 & (1U<<(7U-i))))
        {
            ILI9163_SetPin_SDA(ePinLevelHigh);
        }
        else
        {
            ILI9163_SetPin_SDA(ePinLevelLow);
        }
        ILI9163_SetPin_SCL(ePinLevelHigh);
    }

    ILI9163_SetPin_CS(ePinLevelHigh); /* Release the bus. */
}

void ILI9163_WriteParam16(uint16_t dat16)
{
    uint8_t tmp8;

    tmp8 = (uint8_t)(0xFF&(dat16>>8));
    ILI9163_WriteParam8(tmp8);
    tmp8 = (uint8_t)(0xFF&dat16);
    ILI9163_WriteParam8(tmp8);
}

void ILI9163_Init(void)
{
    ILI9163_InitPinsGPIO();

    /* Reset the device. */
    ILI9163_SetPin_Reset(ePinLevelLow);
    ILI9163_DelayMs(50);
    ILI9163_SetPin_Reset(ePinLevelHigh);
    ILI9163_DelayMs(100);

    ILI9163_WriteCmd(0x11);                   //关闭睡眠，振荡器工作
    ILI9163_DelayMs(100);
    
    ILI9163_WriteCmd(0x3a);                   //每次传送16位数据(VIPF3-0=0101)，每个像素16位(IFPF2-0=101)
    ILI9163_WriteParam8(0x55);                     
   
    ILI9163_WriteCmd(0x26);                   
    ILI9163_WriteParam8(0x04);
    
    ILI9163_WriteCmd(0xf2);                   //Driver Output Control(1)
    ILI9163_WriteParam8(0x01);
    
    ILI9163_WriteCmd(0xe0);                   //Driver Output Control(1)
    ILI9163_WriteParam8(0x3f);
    ILI9163_WriteParam8(0x25);
    ILI9163_WriteParam8(0x1c);
    ILI9163_WriteParam8(0x1e);
    ILI9163_WriteParam8(0x20);
    ILI9163_WriteParam8(0x12);
    ILI9163_WriteParam8(0x2a);
    ILI9163_WriteParam8(0x90);
    ILI9163_WriteParam8(0x24);
    ILI9163_WriteParam8(0x11);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);
     
    ILI9163_WriteCmd(0xe1);              //Driver Output Control(1)
    ILI9163_WriteParam8(0x20);
    ILI9163_WriteParam8(0x20);
    ILI9163_WriteParam8(0x20);
    ILI9163_WriteParam8(0x20);
    ILI9163_WriteParam8(0x05);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x15);
    ILI9163_WriteParam8(0xa7);
    ILI9163_WriteParam8(0x3d);
    ILI9163_WriteParam8(0x18);
    ILI9163_WriteParam8(0x25);
    ILI9163_WriteParam8(0x2a);
    ILI9163_WriteParam8(0x2b);
    ILI9163_WriteParam8(0x2b);  
    ILI9163_WriteParam8(0x3a);  
    
    ILI9163_WriteCmd(0xb1);               //设置屏幕刷新频率
    ILI9163_WriteParam8(0x08);                 //DIVA=8
    ILI9163_WriteParam8(0x08);                 //VPA =8，约90Hz
                       
    ILI9163_WriteCmd(0xb4);               //LCD Driveing control
    ILI9163_WriteParam8(0x07);                 //NLA=1,NLB=1,NLC=1
   
   
    ILI9163_WriteCmd(0xc0);              //LCD Driveing control
    ILI9163_WriteParam8(0x0a);
    ILI9163_WriteParam8(0x02);
      
    ILI9163_WriteCmd(0xc1);              //LCD Driveing control
    ILI9163_WriteParam8(0x02);

    ILI9163_WriteCmd(0xc5);              //LCD Driveing control
    ILI9163_WriteParam8(0x4f);
    ILI9163_WriteParam8(0x5a);

    ILI9163_WriteCmd(0xc7);              //LCD Driveing control
    ILI9163_WriteParam8(0x40);
    
    ILI9163_WriteCmd(0x2a);               //配置MCU可操作的LCD内部RAM横坐标起始、结束参数
    ILI9163_WriteParam8(0x00);                 //横坐标起始地址0x0000
    ILI9163_WriteParam8(0x00);                 
    ILI9163_WriteParam8(0x00);                 //横坐标结束地址0x007f(127)
    ILI9163_WriteParam8(0x7f);
   
    ILI9163_WriteCmd(0x2b);               //配置MCU可操作的LCD内部RAM纵坐标起始结束参数
    ILI9163_WriteParam8(0x00);                 //纵坐标起始地址0x0000
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);                 //纵坐标结束地址0x009f(159)
    ILI9163_WriteParam8(0x9f);

    ILI9163_WriteCmd(0x36);               //配置MPU和DDRAM对应关系
    ILI9163_WriteParam8(0xc0);                 //MX=1,MY=1

    ILI9163_WriteCmd(0xb7);               //LCD Driveing control
    ILI9163_WriteParam8(0x00);                 //CRL=0
       
    ILI9163_WriteCmd(0x29);               //开启屏幕显示
    ILI9163_WriteCmd(0x2c);               //设置为LCD接收数据/命令模式

    ILI9163_DelayMs(50);
}

void ILI9163_SetWindow(uint8_t xs, uint8_t ys, uint8_t xe, uint8_t ye)
{
    ILI9163_WriteCmd(0x2A);       //Colulm addRSTs set
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(xs);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(xe);

    ILI9163_WriteCmd(0x2B);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(ys);
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(ye);

    ILI9163_WriteCmd(0x2C); /* Update GRAM. */
}

void ILI9163_ResetWindow(void)
{
    ILI9163_SetWindow(0U, 0U, ILI9163_WIDTH_MAX-1, ILI9163_HEIGHT_MAX-1);
/*
    ILI9163_WriteCmd(0x2a);               //配置MCU可操作的LCD内部RAM横坐标起始、结束参数
    ILI9163_WriteParam8(0x00);                 //横坐标起始地址0x0000
    ILI9163_WriteParam8(0x00);                 
    ILI9163_WriteParam8(0x00);                 //横坐标结束地址0x007f(127)
    ILI9163_WriteParam8(0x7f);
   
    ILI9163_WriteCmd(0x2b);               //配置MCU可操作的LCD内部RAM纵坐标起始结束参数
    ILI9163_WriteParam8(0x00);                 //纵坐标起始地址0x0000
    ILI9163_WriteParam8(0x00);
    ILI9163_WriteParam8(0x00);                 //纵坐标结束地址0x009f(159)
    ILI9163_WriteParam8(0x9f);

    ILI9163_WriteCmd(0x2C);       //GRAM接收MCU数据或命令
*/
}

void ILI9163_FillScreen(uint16_t color)
{
    uint8_t i,j;

    ILI9163_ResetWindow();
    for (i = 0U; i < ILI9163_HEIGHT_MAX; i++)
    {
        for (j = 0U; j < ILI9163_WIDTH_MAX; j++)
        {
            ILI9163_WriteParam16(color);
        }
    }
}

void ILI9163_SetPixel(uint8_t x, uint8_t y, uint16_t color)
{
    ILI9163_SetWindow(x,y,x,y);
    ILI9163_WriteParam16(color);
}



