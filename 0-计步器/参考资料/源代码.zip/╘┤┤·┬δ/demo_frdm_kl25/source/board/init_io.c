/* init_board.c */

#include "app_inc.h"
#include "MKL25Z4.h"

void init_io(void)
{
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

/* UART. */
void init_io_uart(void)
{
    PORTA->PCR[1] = PORT_PCR_MUX(2); /* UART0_RX. */
    PORTA->PCR[2] = PORT_PCR_MUX(2); /* UART0_TX. */
}

/* LEDs. */
void init_io_leds(void)
{
    PORTB->PCR[18] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK; /* RED. */
    PORTB->PCR[19] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK; /* GREEN. */
    PORTD->PCR[1]  = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK; /* BLUE. */
}

/* I2C. */
void init_io_i2c(void)
{
    PORTE->PCR[24] = PORT_PCR_MUX(5); /* I2C0_SCL. */
    PORTE->PCR[25] = PORT_PCR_MUX(5); /* I2C0_SDA. */
}

/* TPM - PWM - LEDs. */
void init_io_tpm(void)
{
    PORTB->PCR[18] = PORT_PCR_MUX(3) | PORT_PCR_DSE_MASK; /* R */
    PORTB->PCR[19] = PORT_PCR_MUX(3) | PORT_PCR_DSE_MASK; /* G */
    PORTD->PCR[1]  = PORT_PCR_MUX(4) | PORT_PCR_DSE_MASK; /* B */
}

/* TSI. */
void init_io_tsi(void)
{
    PORTB->PCR[16] = PORT_PCR_MUX(0);/* TSI_CH9 */
    PORTB->PCR[17] = PORT_PCR_MUX(0);/* TSI_CH10 */
}

void init_io_lptmr(void)
{
    SIM->SOPT1 |= SIM_SOPT1_OSC32KSEL(3);
}

/* SPI. */
void init_io_spi(uint32_t instance)
{
    switch (instance)
    {
    case 0U:
        /* Pull up resisters are already on board. */
        //PORTC->PCR[4] = PORT_PCR_MUX(2); /* PTC4 - SPI0_PCS0 */
        PORTC->PCR[4] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK; /* GPIO. */
        PORTC->PCR[5] = PORT_PCR_MUX(2); /* PTC5 - SPI0_CLK */
        PORTC->PCR[6] = PORT_PCR_MUX(2); /* PTC6 - SPI0_MOSI */
        PORTC->PCR[7] = PORT_PCR_MUX(2) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; /* PTC7 - SPI0_MISO */
        break;
    case 1U:
        PORTD->PCR[6]  = PORT_PCR_MUX(5); /* SPI1_MISO. */
        PORTD->PCR[7]  = PORT_PCR_MUX(5); /* SPI1_MOSI. */
        PORTB->PCR[10] = PORT_PCR_MUX(1); /* SPI1_CS0, GPIO. */
        PORTB->PCR[11] = PORT_PCR_MUX(2); /* SPI1_SCLK. */
        break;
    default:
        break;
    }
}

/* TFT. */
void init_io_ili9163(void)
{
    /* TFT-CS:  D3  PTA12 */
    /* TFT-CLK: D4  PTA4  */
    /* TFT-DAT: D5  PTA5  */
    /* TFT-CMD: D6  PTC8  */
    /* TFT-RST: D7  PTC9  */

    /* D3 - PTA12. */
    PORTA->PCR[12] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
    /* D4 - PTA4. */
    PORTA->PCR[4] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
    /* D5 - PTA5. */
    PORTA->PCR[5] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
    /* D6 - PTC8. */
    PORTC->PCR[8] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
    /* D7 - PTC9. */
    PORTC->PCR[9] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
    /* D8 - PTA13 */
    //PORTA->PCR[13] = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;
}

void init_io_buttons(void)
{
    PORTE->PCR[2] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    PORTE->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    PORTE->PCR[4] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    PORTE->PCR[5] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
    PORTE->PCR[20] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;
}
