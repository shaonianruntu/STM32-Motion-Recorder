/* init_io.h */
#ifndef __INIT_IO_H__
#define __INIT_IO_H__

#include <stdint.h>
#include <stdbool.h>

/******************************************************************************
* System Bus Configuration.
******************************************************************************/
#define BSP_CORE_CLK_HZ            (48000000U)
#define BSP_BUS_CLK_HZ             (24000000U)

/******************************************************************************
* UART Configuration.
******************************************************************************/
#define BSP_UART_DEBUG_INSTANCE    (0U)
#define BSP_UART_DEBUG_BAUDRATE    (115200U)

/******************************************************************************
* GPIO Configuration.
******************************************************************************/
/* RED. */
#define BSP_LED_PORT_RED           (1U)
#define BSP_LED_PIN_RED            (18U)
/* GREEN. */
#define BSP_LED_PORT_GREEN         (1U)
#define BSP_LED_PIN_GREEN          (19U)
/* BLUE. */
#define BSP_LED_PORT_BLUE          (3U)
#define BSP_LED_PIN_BLUE           (1U)

/******************************************************************************
* Systick Configuration.
******************************************************************************/
#define BSP_SYSTICK_TICKS_PER_SECOND  (200U)

/******************************************************************************
* I2C Configuration.
******************************************************************************/
#define BSP_AXS_I2C_INSTANCE       (0U)
#define BSP_AXS_I2C_BAUDRATE       (3000000U)

/******************************************************************************
* TPM/PWM Timer Configuration.
******************************************************************************/
#define BSP_TPM_PWM_INSTANCE      (2U)
#define BSP_TPM_PWM_CHN0          (0U)
#define BSP_TPM_MODULO            (1000U)
/* RED. */
#define BSP_TPM_PWM_RED_INSTANCE  (2U)
#define BSP_TPM_PWM_RED_CHN       (0U)
/* GREEN. */
#define BSP_TPM_PWM_GREEN_INSTANCE  (2U)
#define BSP_TPM_PWM_GREEN_CHN       (1U)
/* BLUE. */
#define BSP_TPM_PWM_BLUE_INSTANCE  (0U)
#define BSP_TPM_PWM_BLUE_CHN       (1U)

/******************************************************************************
* TSI Configuration.
******************************************************************************/
#define BSP_TSI_INSTANCE    (0U)
#define BSP_TSI_CHN0        (9U)
#define BSP_TSI_CHN1        (10U)

/******************************************************************************
* SPI Configuration.
******************************************************************************/
#define BSP_SPI_SDCARD_INSTANCE (1U)
#define BSP_SPI_SDCARD_BAUDRATE (2000000U)
#define BSP_GPIO_SDCARD_CS_PORT (1U)
#define BSP_GPIO_SDCARD_CS_PIN  (10U)

/******************************************************************************
* GPIO Configuration for button.
******************************************************************************/
#define BSP_GPIO_BTN_PORT    (4U)
#define BSP_GPIO_BTN_PIN1    (2U)
#define BSP_GPIO_BTN_PIN2    (3U)
#define BSP_GPIO_BTN_PIN3    (4U)
#define BSP_GPIO_BTN_PIN4    (5U)
#define BSP_GPIO_BTN_PIN5    (20U)


void init_io(void);
void init_io_uart(void);
void init_io_leds(void);
void init_io_i2c(void);
void init_io_tpm(void);
void init_io_tsi(void);
void init_io_lptmr(void);
void init_io_spi(uint32_t instance);
void init_io_ili9163(void);
void init_io_buttons(void);
#endif /* __INIT_IO_H__ */
