/* fsl_tpm.h */
#ifndef __FSL_TPM_H__
#define __FSL_TPM_H__

#include <stdint.h>
#include <stdbool.h>

/* Define type for enumuration of TPM's divider. */
typedef enum
{
    eTPMDividerOf1   = 0U,
    eTPMDividerOf2   = 1U,
    eTPMDividerOf4   = 2U,
    eTPMDividerOf8   = 3U,
    eTPMDividerOf16  = 4U,
    eTPMDividerOf32  = 5U,
    eTPMDividerOf64  = 6U,
    eTPMDividerOf128 = 7U 
} tpm_divider_t;

/* Define type for enumuration of PWM's aligned mode. */
typedef enum
{
    eTPMAlignedByEdge   = 0U, /* Edge-Aligned PWM (EPWM) Mode. */
    eTPMAlignedByCenter = 1U  /* Center-Aligned PWM (CPWM) Mode. */
} tpm_align_t;

/* Define type for enumuration of PWM's polarity mode. */
typedef enum
{
    eTPMPwmPolLow  = 0U,  /* Low level when in idle. */
    eTPMPwmPolHigh = 1U,  /* High level when in idle. */
} tpm_pwm_polarity_t;

/* Define type of structure for configuring TPM. */
typedef struct
{
    bool            enInt;   /* Timer Overflow Interrupt Enable. */
    tpm_divider_t   Divider; /* Select the division factors for the counter. */
    uint16_t        Modulo;  /* Modulo value for the LPTPM counter. */
    tpm_align_t     AlignMode;
} tpm_config_t;

/* Define type of structure for configuring the PWM. */
typedef struct
{
    tpm_pwm_polarity_t  PloarityMode;
    uint16_t PwmCounter; /*  */
    bool enChnInt;  /* Channel Interrupt Enable */
} tpm_pwm_config_t;

/*****************************************************************************/
/* New APIs. */
/*****************************************************************************/
bool TPM_Init(uint32_t instance, const tpm_config_t *configPtr);
void TPM_Start(uint32_t instance);
void TPM_Pause(uint32_t instance);
bool TPM_GetTmrOverFlowFlag(uint32_t instance);
void TPM_ClearTmrOverFlowFlag(uint32_t instance);
void TPM_InstallCallback(uint32_t instance, void (*callbackFunc)(void));
/* For PWM. */
bool TPM_ConfigPWMChn(uint32_t instance, uint32_t chn, tpm_pwm_config_t *configPtr);
bool TPM_GetPWMChnFlag(uint32_t instance, uint32_t chn);
void TPM_ClearPWMChnFlag(uint32_t instance, uint32_t chn);

#endif /* __FSL_PWM_H__ */
