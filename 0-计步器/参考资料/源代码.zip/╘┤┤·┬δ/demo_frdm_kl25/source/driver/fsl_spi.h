/* fsl_spi.h */
#ifndef __FSL_SPI_H__
#define __FSL_SPI_H__

#include <stdint.h>
#include <stdbool.h>

typedef enum
{
    eSpiPolPhaMode0 = 0U, /* Clock line is low when idle. Data valid when at falling edge. */
    eSpiPolPhaMode1 = 1U, /* Clock line is low when idle. Data valid when at rising edge. */
    eSpiPolPhaMode2 = 2U, /* Clock line is high when idle. Data valid when at falling edge. */
    eSpiPolPhaMode3 = 3U  /* Clock line is high when idle. Data valid when at rising edge. */
} spi_polpha_mode_t;

/* Defaultly work as master. */
typedef struct
{
    uint32_t BusClkHz;
    uint32_t Baudrate;
    spi_polpha_mode_t PolPhaMode;
    bool enAuotCs;
    bool enLSB;
} spi_config_t;

bool SPI_Init(uint32_t instance, const spi_config_t *configPtr);
void SPI_Deinit(uint32_t instance);
uint8_t SPI_SwapByte(uint32_t instance, uint8_t txData);
uint32_t SPI_SetBaudrate(uint32_t instance, uint32_t busClkHz, uint32_t baudrate);

#endif /* __FSL_SPI_H__ */
