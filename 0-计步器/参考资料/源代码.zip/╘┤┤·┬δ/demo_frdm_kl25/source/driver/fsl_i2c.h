/* fsl_i2c.h */
#ifndef __FSL_I2C_H__
#define __FSL_I2C_H__
#include <stdint.h>
#include <stdbool.h>

#define I2C_READ_CMD        (1U)
#define I2C_WRITE_CMD       (0U)

typedef struct
{
    uint32_t BusClkHz;
    uint32_t Baudrate;
} i2c_config_t;

bool I2C_Init(uint32_t instance, const i2c_config_t *configPtr);
void I2C_Start(uint32_t instance);
void I2C_Stop(uint32_t instance);
void I2C_Restart(uint32_t instance);
void I2C_PutByte(uint32_t instance, uint8_t ch);
uint8_t I2C_GetByte(uint32_t instance);
void I2C_WaitAck(uint32_t instance);
bool I2C_GetAck(uint32_t instance);
void I2C_SendAck(uint32_t instance);
void I2C_SendNAck(uint32_t instance);
bool I2C_IsBusy(uint32_t instance);

void I2C_SetTxMode(uint32_t instance);
void I2C_SetRxMode(uint32_t instance);

void I2C_ReadBytes(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t *rxBufPtr, /* Pointer to the reading stream. */
                   uint32_t rxLen     /* Length of the reading stream. */
);

void I2C_WriteBytes(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t *txBufPtr, /* Pointer to the writing stream. */
                   uint32_t txLen     /* Length of the writing stream. */
);

void I2C_WriteByte(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t txByte    /* Byte to write. */
);

#endif /* __FSL_I2C_H__ */
