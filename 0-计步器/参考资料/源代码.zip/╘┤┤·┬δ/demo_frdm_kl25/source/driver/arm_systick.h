/* arm_systick.h */
#ifndef __ARM_SYSTICK_H__
#define __ARM_SYSTICK_H__

#include <stdint.h>
#include <stdbool.h>

typedef struct
{
    uint32_t CoreClkHz;
    uint32_t TicksPerSecond;
} systick_config_t;

bool SYSTICK_Init(const systick_config_t *configPtr);
void SYSTICK_DelayTicks(uint32_t ticks);
void SYSTICK_InstallCallback(void (*callbackFunc)(void));

#endif /* __ARM_SYSTICK_H__ */
