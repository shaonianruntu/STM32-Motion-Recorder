/* fsl_uart.h */
#ifndef __FSL_UART_H__
#define __FSL_UART_H__

#include <stdint.h>
#include <stdbool.h>

typedef struct
{
    uint32_t BusClkHz;
    uint32_t Baudrate;
} uart_config_t;

bool UART0_Init(const uart_config_t *configPtr);
void UART0_PutChar(uint8_t ch);
uint8_t UART0_GetChar(void);

#endif /* __FSL_UART_H__ */
