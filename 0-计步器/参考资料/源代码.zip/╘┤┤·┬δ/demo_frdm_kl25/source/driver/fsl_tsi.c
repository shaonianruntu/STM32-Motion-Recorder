/* fsl_tsi.c */

#include "fsl_tsi.h"
#include "MKL25Z4.h"

static TSI_Type * const g_TsiBasePtr[] = TSI_BASES;

static void TSI_InitIO(uint32_t instance)
{
    switch (instance)
    {
    case 0U:
        SIM->SCGC5 |= SIM_SCGC5_TSI_MASK;
        break;
    default:
        break;
    }
}

bool TSI_Init(uint32_t instance)
{
    TSI_InitIO(instance);
    g_TsiBasePtr[instance]->GENCS =   TSI_GENCS_TSIEN_MASK
                                    | TSI_GENCS_NSCN(4U)
                                    | TSI_GENCS_PS(4U) /* ɨ��Ƶ�����ɴ�֮�� */
                                    | TSI_GENCS_REFCHRG(4U)
                                    | TSI_GENCS_EXTCHRG(4U)
                                    | TSI_GENCS_OUTRGF_MASK /* Clear flags. */
                                    | TSI_GENCS_EOSF_MASK;
    
    return true;
}
uint16_t TSI_GetChnValue(uint32_t instance, uint32_t chn)
{
    g_TsiBasePtr[instance]->DATA =    TSI_DATA_TSICH(chn) /* Set Channel */
                                    | TSI_DATA_SWTS_MASK; /* Software Trigger. */
    
    /* Wait the conversion to be finished. */
    while (!(g_TsiBasePtr[instance]->GENCS & TSI_GENCS_EOSF_MASK) ) {}
    g_TsiBasePtr[instance]->GENCS |= TSI_GENCS_EOSF_MASK;
        
    return (uint16_t)(g_TsiBasePtr[instance]->DATA & TSI_DATA_TSICNT_MASK);
}
