/* fsl_tpm.c */
#include "fsl_tpm.h"
#include "MKL25Z4.h"

typedef struct
{
    void (*CallbackFunc)(void);
} tpm_context_t;

static TPM_Type * const g_TpmBasePtr[] = TPM_BASES;
#define TPM_INSTANCE_COUNT  ( (sizeof(g_TpmBasePtr))/(sizeof(g_TpmBasePtr[0])))
static IRQn_Type g_TpmIrqId[] = {TPM0_IRQn, TPM1_IRQn, TPM2_IRQn};
static tpm_context_t g_TpmContextStruct[TPM_INSTANCE_COUNT];

static void TPM_InitIO(uint32_t instance)
{
    switch (instance)
    {
    case 0U:
        SIM->SCGC6	|= SIM_SCGC6_TPM0_MASK;
        break;
    case 1U:
        SIM->SCGC6	|= SIM_SCGC6_TPM1_MASK;
        break;
    case 2U:
        SIM->SCGC6	|= SIM_SCGC6_TPM2_MASK;
        break;
    default:
        break;
    }
}

bool TPM_Init(uint32_t instance, const tpm_config_t *configPtr)
{
    if (!configPtr)
    {
        return false;
    }
    
    TPM_InitIO(instance);
    
    /* Disable the TMP and reset its control register bits. */
    g_TpmBasePtr[instance]->SC = 0U;
    
    /* Use MCGFLLCLK clock or MCGPLLCLK/2. */
    SIM->SOPT2	|= SIM_SOPT2_TPMSRC(1); 
    
    /* Configure work mode the TPM. */
    g_TpmBasePtr[instance]->SC = ((configPtr->enInt)? TPM_SC_TOIE_MASK:0U)
                                | ((configPtr->AlignMode == eTPMAlignedByCenter)? TPM_SC_CMOD_MASK:0U)
                                | TPM_SC_PS(configPtr->Divider);
    
    /* Set the modulo for TPM. */
    g_TpmBasePtr[instance]->MOD = TPM_MOD_MOD(configPtr->Modulo);
    
    if (configPtr->enInt)
    {
        NVIC_EnableIRQ(g_TpmIrqId[instance]);
    }
    else
    {
        NVIC_DisableIRQ(g_TpmIrqId[instance]);
    }
    
    return true;
}

void TPM_Start(uint32_t instance)
{
    /* Enable the TPM. */
    g_TpmBasePtr[instance]->SC |= TPM_SC_CMOD(1);
}

void TPM_Pause(uint32_t instance)
{
    /* Disable the TPM. */
    g_TpmBasePtr[instance]->SC &= ~TPM_SC_CMOD_MASK;
}

bool TPM_GetTmrOverFlowFlag(uint32_t instance)
{
    return (0U != (g_TpmBasePtr[instance]->SC & TPM_SC_TOF_MASK) );
}

void TPM_ClearTmrOverFlowFlag(uint32_t instance)
{
    g_TpmBasePtr[instance]->SC |=TPM_SC_TOF_MASK;
}

bool TPM_ConfigPWMChn(uint32_t instance, uint32_t chn, tpm_pwm_config_t *configPtr)
{   
    if (!configPtr)
    {
        return false;
    }
    
    /* ���ض��룬���е�ƽΪ�ͣ���Ч��ƽΪ�ߡ� */
    g_TpmBasePtr[instance]->CONTROLS[chn].CnSC = TPM_CnSC_MSB_MASK
                                               | ((configPtr->PloarityMode == eTPMPwmPolHigh)?TPM_CnSC_ELSA_MASK:TPM_CnSC_ELSB_MASK)
                                               | ((configPtr->enChnInt)? TPM_CnSC_CHIE_MASK: 0U);
    /* Set cycle period. */
    g_TpmBasePtr[instance]->CONTROLS[chn].CnV = configPtr->PwmCounter;

    return true;
}

bool TPM_GetPWMChnFlag(uint32_t instance, uint32_t chn)
{
    return ( 0U != (g_TpmBasePtr[instance]->CONTROLS[chn].CnSC & TPM_CnSC_CHF_MASK));
}

void TPM_ClearPWMChnFlag(uint32_t instance, uint32_t chn)
{
    g_TpmBasePtr[instance]->CONTROLS[chn].CnSC |= TPM_CnSC_CHF_MASK;
}

void TPM_InstallCallback(uint32_t instance, void (*callbackFunc)(void))
{
    g_TpmContextStruct[instance].CallbackFunc = callbackFunc;
}

void TPM_ISRHandler(uint32_t instance)
{
    if (g_TpmContextStruct[instance].CallbackFunc)
    {
        (void)(*(g_TpmContextStruct[instance].CallbackFunc))();
    }
    TPM_ClearTmrOverFlowFlag(instance);
}

void TPM0_IRQHandler(void)
{
    TPM_ISRHandler(0U);
}

void TPM1_IRQHandler(void)
{
    TPM_ISRHandler(1U);
}

void TPM2_IRQHandler(void)
{
    TPM_ISRHandler(2U);
}

