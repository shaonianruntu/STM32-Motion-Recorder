/* arm_systick.c */
#include "arm_systick.h"
#include "MKL25Z4.h"

typedef struct
{
    void (*CallbackFunc)(void);
    volatile uint32_t Counter;
} systick_context_t;

static systick_context_t g_SystickContextStruct;

bool SYSTICK_Init(const systick_config_t *configPtr)
{
    if (!configPtr)
    {
        return false;
    }
    g_SystickContextStruct.CallbackFunc = (void *)0U;
    g_SystickContextStruct.Counter = 0U;
    
    /* Set core clock as clock source. */
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk; 
    /* Set reload value. */
    SysTick->LOAD = configPtr->CoreClkHz / configPtr->TicksPerSecond;
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk  /* Enable the Interrupt. */
                   | SysTick_CTRL_ENABLE_Msk;  /* Enable the Systick. */

    return true;
}

void SYSTICK_DelayTicks(uint32_t ticks)
{
    g_SystickContextStruct.Counter = ticks;
    while (g_SystickContextStruct.Counter > 0U)
    {}
}

void SYSTICK_InstallCallback(void (*callbackFunc)(void))
{
    g_SystickContextStruct.CallbackFunc = callbackFunc;
}

void SysTick_Handler(void)
{
    /* Decrease the counter. */
    if (g_SystickContextStruct.Counter > 0U)
    {
        g_SystickContextStruct.Counter--;
    }
    
    /* Execute the callback function. */
    if (g_SystickContextStruct.CallbackFunc)
    {
        (void)(*(g_SystickContextStruct.CallbackFunc))();
    }
}
