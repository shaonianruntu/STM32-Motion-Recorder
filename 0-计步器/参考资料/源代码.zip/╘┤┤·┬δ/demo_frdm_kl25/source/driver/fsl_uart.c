/* fsl_uart.c */

#include "fsl_uart.h"
#include "MKL25Z4.h"

static void UART0_InitIO(void)
{
    /* Open the gate control. */
    SIM->SCGC4 |= SIM_SCGC4_UART0_MASK;
}

bool UART0_Init(const uart_config_t *configPtr)
{
    uint16_t sbr_val;
    
    UART0_InitIO();

    /* Disable the Rx and Tx. */
    UART0->C2 &= ~(UART0_C2_TE_MASK | UART0_C2_RE_MASK);
    
    /* configure uart1 for 8-bit mode , no parity */
    UART0->C1 = 0U;
    
    /* Set UART0 clock source as "MCGFLLCLK clock or MCGPLLCLK/2 clock". */
    SIM->SOPT2 = (SIM->SOPT2 & ~SIM_SOPT2_UART0SRC_MASK) 
               | SIM_SOPT2_UART0SRC(1) | SIM_SOPT2_PLLFLLSEL_MASK;
    
    /* calculate the sbr value. */
    sbr_val = (configPtr->BusClkHz >> 4)/configPtr->Baudrate;
    UART0->BDH = (uint8_t)(((0x1F00 & sbr_val) >> 8)&UART0_BDH_SBR_MASK);
    UART0->BDL = (uint8_t)(sbr_val & UART0_BDL_SBR_MASK);
    
    UART0->C3 = 0U;
    UART0->S1 = 0x1FU;
    UART0->S2 = 0U;
    
    /* enable the tx and rx  */
    UART0->C2 |= (UART0_C2_TE_MASK | UART0_C2_RE_MASK);
    
    return true;
}

void UART0_PutChar(uint8_t ch)
{
    while(!(UART0->S1 & UART0_S1_TDRE_MASK));
    
    /* Send the character */
    UART0->D = ch;
}

uint8_t UART0_GetChar(void)
{
    while (!(UART0->S1 & UART0_S1_RDRF_MASK)){}
    return UART0->D;
}

