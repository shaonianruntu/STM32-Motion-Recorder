/* fsl_spi.c */

#include "fsl_spi.h"
#include "MKL25Z4.h"

static SPI_Type * const g_SpiPtr[] = SPI_BASES;

static void SPI_SetUngate(uint32_t instance, bool enable)
{
    switch (instance)
    {
    case 0U:
        if (enable)
        {
            SIM->SCGC4 |= SIM_SCGC4_SPI0_MASK;
        }
        else
        {
            SIM->SCGC4 &= ~SIM_SCGC4_SPI0_MASK;
        }
        break;
    case 1U:
        if (enable)
        {
            SIM->SCGC4 |= SIM_SCGC4_SPI1_MASK;
        }
        else
        {
            SIM->SCGC4 &= ~SIM_SCGC4_SPI1_MASK;
        }
        break;
    default:
        break;
    }
}

static void SPI_ResetReg(uint32_t instance)
{
    SPI_Type *spiPtr = g_SpiPtr[instance];
    
    spiPtr->C1 = 0x04U;
    spiPtr->C2 = 0x0U;
    spiPtr->BR = 0x0U;
    spiPtr->M = 0x0U;
}

bool SPI_Init(uint32_t instance, const spi_config_t *configPtr)
{
    uint8_t reg = 0;
    SPI_Type *spiPtr = g_SpiPtr[instance];
    
    SPI_SetUngate(instance, true);
    SPI_ResetReg(instance);
    /* Auto CS. */
    if (configPtr->enAuotCs)
    {
        spiPtr->C2 |= SPI_C2_MODFEN_MASK;
        reg |= SPI_C1_SSOE_MASK;
    }
    /* PolPha */
    if (0U != (configPtr->PolPhaMode & 0x01U) )
    {
        reg |= SPI_C1_CPHA_MASK;
    }
    if (0U != (configPtr->PolPhaMode & 0x02U) )
    {
        reg |= SPI_C1_CPOL_MASK;
    }
    /* LSB. */
    if (configPtr->enLSB)
    {
        reg |= SPI_C1_LSBFE_MASK;
    }
    reg |= SPI_C1_SPE_MASK   /* Enable module. */
         | SPI_C1_MSTR_MASK; /* Master as default. */
    
    SPI_SetBaudrate(instance, configPtr->BusClkHz, configPtr->Baudrate);
    spiPtr->C1 = reg;
    
    return true;
}

void SPI_Deinit(uint32_t instance)
{
    SPI_SetUngate(instance, false);
}

uint8_t SPI_SwapByte(uint32_t instance, uint8_t txData)
{
    SPI_Type *spiPtr = g_SpiPtr[instance];
    
    /* Wait till the tx buffer is empty. */
    while (0U == (spiPtr->S & SPI_S_SPTEF_MASK) ) {}
    /* Put the tx data to tx buffer. */
    spiPtr->D = txData;
    /* Wait while the rx buffer is empty. */
    while (0U == (spiPtr->S & SPI_S_SPRF_MASK) ) {}
    /* Get the rx data from rx buffer. */
    return spiPtr->D;
}

uint32_t SPI_SetBaudrate(uint32_t instance, uint32_t busClkHz, uint32_t baudrate)
{
    SPI_Type *spiPtr = g_SpiPtr[instance];
    const uint32_t SPPR_Val[] = {1U, 2U, 3U, 4U, 5U, 6U, 7U, 8U};
    const uint32_t SPR_Val[] = {2U, 4U, 8U, 16U, 32U, 64U, 128U, 256U, 512U};
    uint8_t sppr, spr, sppr_min = 0xFFU, spr_min = 0xFFU;
    uint32_t diff_min = 0xFFFFFFFFU; 
    uint32_t tmp32;
    
    for (sppr = 0U; sppr < 8U; sppr++)
    {
        for (spr = 0U; spr < 8U; spr++)
        {
            tmp32 = baudrate * SPPR_Val[sppr] * SPR_Val[spr];
            if (tmp32 >= busClkHz)
            {
                tmp32 -= busClkHz;
                if (tmp32 <diff_min)
                {
                    diff_min = tmp32;
                    sppr_min = sppr;
                    spr_min = spr;
                }
            }
        }
    }
    spiPtr->BR = SPI_BR_SPPR(sppr_min) | SPI_BR_SPR(spr_min);
    
    return diff_min;
}
