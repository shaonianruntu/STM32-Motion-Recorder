/* fsl_pit.h */
#ifndef __FSL_PIT_H__
#define __FSL_PIT_H__

#include <stdint.h>
#include <stdbool.h>

typedef struct
{
    bool enInDebugMode; /* Timer can work in Debug mode. */
    bool enUseInt;  /* Enable the interrupt switcher. */
} pit_config_t;

typedef struct
{
    bool enInt;
    uint32_t PeriodClkCount;
    bool enChainMode;
} pit_chn_config_t;

bool PIT_Init(const pit_config_t *configPtr);
void PIT_Deinit(void);
void PIT_Start(void);
void PIT_Stop(void);
bool PIT_ConfigChn(uint32_t chn, pit_chn_config_t *configPtr);
void PIT_PauseChn(uint32_t chn);
bool PIT_GetChnFlag(uint32_t chn);
void PIT_ClearChnFlag(uint32_t chn);
void PIT_IntHandler(void);
void PIT_InstallCallbackForChn(uint32_t chn, void (*func)(void) );

#endif /* __FSL_PIT_H__ */
