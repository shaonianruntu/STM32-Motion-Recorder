/* fsl_gpio.h */
#ifndef __FSL_GPIO_H__
#define __FSL_GPIO_H__

#include <stdint.h>
#include <stdbool.h>

void GPIO_SetPinDir(uint32_t port, uint32_t pin, bool enDirOut);
void GPIO_SetPinLogic(uint32_t port, uint32_t pin, bool enLogicOne);
void GPIO_TogglePinLogic(uint32_t port, uint32_t pin);
bool GPIO_GetPinLogic(uint32_t port, uint32_t pin);

#endif /* __FSL_GPIO_H__ */

