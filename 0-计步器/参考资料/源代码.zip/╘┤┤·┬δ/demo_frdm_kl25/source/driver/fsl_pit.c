/* fsl_pit.c */
#include "fsl_pit.h"
#include "MKL25Z4.h"
#include "core_cm0plus.h"

#define PIT_CHN_INSTANCE_COUNT    (2U)

typedef struct
{
    void (*ChnCallbackFunc[PIT_CHN_INSTANCE_COUNT])(void);
} pit_context_t;

static pit_context_t PitContextStruct;

bool PIT_Init(const pit_config_t *configPtr)\
{
    uint32_t i;
    
    if (!configPtr)
    {
        return false;
    }
    /* UnGate access. */
    SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;

    /* Configure the PIT. */
    PIT->MCR = PIT_MCR_MDIS_MASK /* Disable timer, will be enable when calling PIT_Start(). */
             | ( (configPtr->enInDebugMode)?0U:PIT_MCR_FRZ_MASK );
    
    /* Configure the NVIC. */
    if (configPtr->enUseInt)
    {
        NVIC_EnableIRQ(PIT_IRQn);
    }
    else
    {
        NVIC_DisableIRQ(PIT_IRQn);
    }
    
    for (i = 0U; i < PIT_CHN_INSTANCE_COUNT; i++)
    {
        PitContextStruct.ChnCallbackFunc[i] = (void *)0U;
    }
    return true;
}
void PIT_Deinit(void)
{
    PIT->MCR = PIT_MCR_MDIS_MASK;
    NVIC_DisableIRQ(PIT_IRQn);
    SIM->SCGC6 &= ~SIM_SCGC6_PIT_MASK;
}

void PIT_Start(void)
{
    PIT->MCR &= ~PIT_MCR_MDIS_MASK;
}

void PIT_Stop(void)
{
    PIT->MCR |= PIT_MCR_MDIS_MASK;
}

bool PIT_ConfigChn(uint32_t chn, pit_chn_config_t *configPtr)
{
    PIT->CHANNEL[chn].TCTRL = 0U;
    PIT->CHANNEL[chn].LDVAL = configPtr->PeriodClkCount;
    PIT->CHANNEL[chn].TCTRL = ( (configPtr->enChainMode)?PIT_TCTRL_CHN_MASK:0U )
                            | ( (configPtr->enInt)?PIT_TCTRL_TIE_MASK:0U )
                            | PIT_TCTRL_TEN_MASK; /* Enable the channel. */
    return true;
}

void PIT_PauseChn(uint32_t chn)
{
    PIT->CHANNEL[chn].TCTRL &= ~PIT_TCTRL_TEN_MASK;
}

bool PIT_GetChnFlag(uint32_t chn)
{
    return ( 0U != (PIT->CHANNEL[chn].TFLG & PIT_TFLG_TIF_MASK) );
}

void PIT_ClearChnFlag(uint32_t chn)
{
    PIT->CHANNEL[chn].TFLG = PIT_TFLG_TIF_MASK;
}

void PIT_InstallCallbackForChn(uint32_t chn, void (*func)(void) )
{
    PitContextStruct.ChnCallbackFunc[chn] = func;
}

void PIT_IntHandler(void)
{
    uint32_t chn;
    for (chn = 0U; chn < PIT_CHN_INSTANCE_COUNT; chn++)
    {
        if (PIT_GetChnFlag(chn))
        {
            if (PitContextStruct.ChnCallbackFunc[chn])
            {
                (void)(*(PitContextStruct.ChnCallbackFunc[chn]))();
            }
            PIT_ClearChnFlag(chn);
        }
    }
}

void PIT_IRQHandler()
{
    PIT_IntHandler();
}
