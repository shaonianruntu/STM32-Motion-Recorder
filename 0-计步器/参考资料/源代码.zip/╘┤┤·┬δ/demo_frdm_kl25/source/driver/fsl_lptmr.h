/* fsl_lptmr.h */
#ifndef __FSL_LPTMR_H__
#define __FSL_LPTMR_H__

#include <stdint.h>
#include <stdbool.h>

typedef enum
{
    eLptmrDividerOf2    = 0U,
    eLptmrDividerOf4    = 1U,
    eLptmrDividerOf8    = 2U,
    eLptmrDividerOf16   = 3U,
    eLptmrDividerOf32   = 4U,
    eLptmrDividerOf64   = 5U,
    eLptmrDividerOf128  = 6U,
    eLptmrDividerOf256  = 7U,
    eLptmrDividerOf512  = 8U,
    eLptmrDividerOf1024 = 9U,
    eLptmrDividerOf2048 = 10U,
    eLptmrDividerOf4096 = 11U,
    eLptmrDividerOf8192 = 12U,
    eLptmrDividerOf16384 = 13U,
    eLptmrDividerOf32768 = 14U,
    eLptmrDividerOf65536 = 15U,
    eLptmrDividerOf1 = 16U /* ByPassed. */
} lptmr_clk_div_t;
    
typedef enum
{
    eLptmrClkSrcOf0 = 0U,  /* MCGIRCLK - internal reference clock(not available in LLS and VLLS modes) */
    eLptmrClkSrcOf1 = 1U,  /* LPO - 1 kHz clock (not available in VLLS0 mode) */
    eLptmrClkSrcOf2 = 2U,  /* ERCLK32K (not available in VLLS0 mode when using 32 kHz oscillator) */
    eLptmrClkSrcOf3 = 3U,  /* OSCERCLK � external reference clock(not available in VLLS0 mode) */
} lptmr_clk_src_t;

typedef struct
{
    uint32_t enInt; /* Switcher to enable interrupt when counter is overflow. */
    bool enFreeRun; /*  Configure the CNR to reset on overflow or not. */
    lptmr_clk_div_t ClkDivider;
    lptmr_clk_src_t ClkSource; /* Selects the clock to be used by the LPTMR prescaler/glitch filter. */
} lptmr_config_tmr_t;

typedef enum
{
    eLptmrPulseInput0 = 0U,
    eLptmrPulseInput1 = 1U,
    eLptmrPulseInput2 = 2U,
    eLptmrPulseInput3 = 3U
} lptmr_pulse_input_t;

typedef enum
{
    eLptmrPolActiveHigh = 0U, /* Counter will increment on the rising-edge. */
    eLptmrPolActiveLow  = 1U  /* Counter will increment on the falling-edge. */
} lptmr_pulse_polarity_t;

typedef struct
{
    uint32_t enInt; /* Switcher to enable interrupt when counter is overflow. */
    lptmr_pulse_input_t InputSource; /* Configures the input source to be used in Pulse Counter mode. */
    lptmr_pulse_polarity_t InputPolarity; /* Configures the polarity of the input source in Pulse Counter mode. */
    bool enFreeRun; /*  configures the CNR to reset on overflow or not. */
    lptmr_clk_div_t ClkDivider;
} lptmr_config_cnt_t;

bool LpTmr_InitTmr(uint32_t instance, const lptmr_config_tmr_t *configPtr);
bool LpTmr_InitCnt(uint32_t instance, const lptmr_config_cnt_t *configPtr);
void LpTmr_Start(uint32_t instance);
void LpTmr_Stop(uint32_t instance);

bool LpTmr_GetTmrOverFlag(uint32_t instance);
void LpTmr_ClearTmrOverFlag(uint32_t instance);
void LpTmr_InstallCallback(uint32_t instance, void (*callbackFunc)(void) );

#endif /* __FSL_LPTMR_H__ */
