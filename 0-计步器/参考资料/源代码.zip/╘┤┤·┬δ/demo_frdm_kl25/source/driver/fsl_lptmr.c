/* fsl_lptmr.c */
#include "fsl_lptmr.h"
#include "MKL25Z4.h"

typedef struct
{
    void (*CallbackFunc)(void);
} lptmr_context_t;

static LPTMR_Type * const g_LptmrBasePtr[] = LPTMR_BASES;
#define LPTMR_INSTANCE_COUNT ( (sizeof(g_LptmrBasePtr))/(sizeof(g_LptmrBasePtr[0])) )
static IRQn_Type g_LptmrIrqId[] = {LPTimer_IRQn};
static lptmr_context_t g_LptmrContextStuct[LPTMR_INSTANCE_COUNT];

static void LpTmr_SetUnGateCmd(uint32_t instance, bool enable)
{
    switch (instance)
    {
    case 0U:
        if (enable)
        {
            SIM->SCGC5 |= SIM_SCGC5_LPTMR_MASK;
        }
        else
        {
            SIM->SCGC5 &= ~SIM_SCGC5_LPTMR_MASK;
        }
        break;
    default:
        break;
    }
}

bool LpTmr_InitTmr(uint32_t instance, const lptmr_config_tmr_t *configPtr)
{
    LpTmr_SetUnGateCmd(instance, true);
    g_LptmrBasePtr[instance]->CSR = 0U;
    g_LptmrBasePtr[instance]->CSR = ( (configPtr->enInt)?LPTMR_CSR_TIE_MASK:0U) 
                                  | ( (configPtr->enFreeRun)?LPTMR_CSR_TFC_MASK:0U );
    if (eLptmrDividerOf1 == configPtr->ClkDivider)
    {
        g_LptmrBasePtr[instance]->PSR = LPTMR_PSR_PBYP_MASK;
    }
    else
    {
        g_LptmrBasePtr[instance]->PSR = LPTMR_PSR_PRESCALE((uint32_t)(configPtr->ClkDivider) );
    }
    g_LptmrBasePtr[instance]->PSR |= LPTMR_PSR_PCS((uint32_t)(configPtr->ClkSource));
    
    /* Configure NVIC. */
    if (configPtr->enInt)
    {
        NVIC_EnableIRQ(g_LptmrIrqId[instance]);
    }
    else
    {
        NVIC_DisableIRQ(g_LptmrIrqId[instance]);
    }
    
    return true;
}

bool LpTmr_InitCnt(uint32_t instance, const lptmr_config_cnt_t *configPtr)
{
    LpTmr_SetUnGateCmd(instance, true);
    g_LptmrBasePtr[instance]->CSR = 0U;
    g_LptmrBasePtr[instance]->CSR = ( (configPtr->enInt)?LPTMR_CSR_TIE_MASK:0U) 
                                  | LPTMR_CSR_TPS(configPtr->InputSource)
                                  | ( (configPtr->InputPolarity == eLptmrPolActiveLow)?LPTMR_CSR_TPP_MASK:0U )
                                  | ( (configPtr->enFreeRun)?LPTMR_CSR_TFC_MASK:0U )
                                  | LPTMR_CSR_TMS_MASK;

    if (eLptmrDividerOf1 == configPtr->ClkDivider)
    {
        g_LptmrBasePtr[instance]->PSR = LPTMR_PSR_PBYP_MASK;
    }
    else
    {
        g_LptmrBasePtr[instance]->PSR = LPTMR_PSR_PRESCALE((uint32_t)(configPtr->ClkDivider) );
    }
    
    /* Configure NVIC. */
    if (configPtr->enInt)
    {
        NVIC_EnableIRQ(g_LptmrIrqId[instance]);
    }
    else
    {
        NVIC_DisableIRQ(g_LptmrIrqId[instance]);
    }
    
    return true;
}

void LpTmr_Start(uint32_t instance)
{
    g_LptmrBasePtr[instance]->CSR = 0U;
}

void LpTmr_Stop(uint32_t instance)
{
    g_LptmrBasePtr[instance]->CSR |= LPTMR_CSR_TEN_MASK;
}

bool LpTmr_GetTmrOverFlag(uint32_t instance)
{
    return (0U != (g_LptmrBasePtr[instance]->CSR & LPTMR_CSR_TCF_MASK));
}

void LpTmr_ClearTmrOverFlag(uint32_t instance)
{
    g_LptmrBasePtr[instance]->CSR |= LPTMR_CSR_TCF_MASK;
}

void LpTmr_InstallCallback(uint32_t instance, void (*callbackFunc)(void) )
{
    g_LptmrContextStuct[instance].CallbackFunc = callbackFunc;
}

void LpTmr_ISRHandler(uint32_t instance)
{
    if (g_LptmrContextStuct[instance].CallbackFunc)
    {
        (void)(*(g_LptmrContextStuct[instance].CallbackFunc))();
    }
    if (LpTmr_GetTmrOverFlag(instance))
    {
        LpTmr_ClearTmrOverFlag(instance);
    }
}

void LPTimer_IRQHandler(void)
{
    LpTmr_ISRHandler(0U);
}
