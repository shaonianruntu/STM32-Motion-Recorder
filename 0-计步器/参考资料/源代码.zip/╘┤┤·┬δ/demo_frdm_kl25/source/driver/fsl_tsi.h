/* fsl_tsi.h */
#ifndef __FSL_TSI_H__
#define __FSL_TSI_H__

#include <stdint.h>
#include <stdbool.h>

bool TSI_Init(uint32_t instance);
uint16_t TSI_GetChnValue(uint32_t instance, uint32_t chn);

#endif /* __FSL_TSI_H__ */
