/* fsl_gpio.c */

#include "fsl_gpio.h"
#include "MKL25Z4.h"

static FGPIO_Type * const g_GpioBasePtr[] = FGPIO_BASES;

void GPIO_SetPinDir(uint32_t port, uint32_t pin, bool enDirOut)
{
    if (enDirOut)
    {
        g_GpioBasePtr[port]->PDDR |= (1U<<pin);
    }
    else
    {
        g_GpioBasePtr[port]->PDDR &= ~(1U<<pin);
    }
}

void GPIO_SetPinLogic(uint32_t port, uint32_t pin, bool enLogicOne)
{
    if (enLogicOne)
    {
        g_GpioBasePtr[port]->PSOR = (1U<<pin);
    }
    else
    {
        g_GpioBasePtr[port]->PCOR = (1U<<pin);
    }
}

void GPIO_TogglePinLogic(uint32_t port, uint32_t pin)
{
    g_GpioBasePtr[port]->PTOR = (1U<<pin);
}

bool GPIO_GetPinLogic(uint32_t port, uint32_t pin)
{
    return (0U != ((1U<<pin)&g_GpioBasePtr[port]->PDIR));
}
