/* fsl_i2c.c */
#include "fsl_i2c.h"
#include "MKL25Z4.h"

//!< clock deiver struct (internal)
typedef struct 
{
    uint8_t icr;            //!< F register ICR value.
    uint16_t sclDivider;    //!< SCL clock divider.
}_I2C_Divider_Type;

//!< @brief I2C divider values.
static const _I2C_Divider_Type I2C_DiverTable[] =
{
    /* ICR  Divider */
    { 0x00, 20 },
    { 0x01, 22 },
    { 0x02, 24 },
    { 0x03, 26 },
    { 0x04, 28 },
    { 0x05, 30 },
    { 0x09, 32 },
    { 0x06, 34 },
    { 0x0a, 36 },
    { 0x07, 40 },
    { 0x0c, 44 },
    { 0x0d, 48 },
    { 0x0e, 56 },
    { 0x12, 64 },
    { 0x0f, 68 },
    { 0x13, 72 },
    { 0x14, 80 },
    { 0x15, 88 },
    { 0x19, 96 },
    { 0x16, 104 },
    { 0x1a, 112 },
    { 0x17, 128 },
    { 0x1c, 144 },
    { 0x1d, 160 },
    { 0x1e, 192 },
    { 0x22, 224 },
    { 0x1f, 240 },
    { 0x23, 256 },
    { 0x24, 288 },
    { 0x25, 320 },
    { 0x26, 384 },
    { 0x2a, 448 },
    { 0x27, 480 },
    { 0x2b, 512 },
    { 0x2c, 576 },
    { 0x2d, 640 },
    { 0x2e, 768 },
    { 0x32, 896 },
    { 0x2f, 960 },
    { 0x33, 1024 },
    { 0x34, 1152 },
    { 0x35, 1280 },
    { 0x36, 1536 },
    { 0x3a, 1792 },
    { 0x37, 1920 },
    { 0x3b, 2048 },
    { 0x3c, 2304 },
    { 0x3d, 2560 },
    { 0x3e, 3072 },
    { 0x3f, 3840 }
};

static I2C_Type * const g_I2cBasePtr[] = I2C_BASES;
#define I2C_INSTANCE_COUNT   ( (sizeof(g_I2cBasePtr)) / (sizeof(g_I2cBasePtr[0])))

static void I2C_SetUnGateCmd(uint32_t instance, bool enable)
{
    switch (instance)
    {
    case 0U:
        if (enable)
        {
            SIM->SCGC4 |= SIM_SCGC4_I2C0_MASK;
        }
        else
        {
            SIM->SCGC4 &= ~SIM_SCGC4_I2C0_MASK;
        }
        break;
    case 1U:
        if (enable)
        {
            SIM->SCGC4 |= SIM_SCGC4_I2C1_MASK;
        }
        else
        {
            SIM->SCGC4 &= ~SIM_SCGC4_I2C1_MASK;
        }
        break;
    default:
        break;
    }
}
static uint8_t I2C_CalcBaudrate(uint32_t busClkHz, uint32_t baudrate)
{
    uint32_t mult;
    uint32_t hz = baudrate;
    uint32_t bestError = 0xffffffffu;
    uint32_t bestMult = 0u;
    uint32_t bestIcr = 0u;
    
    if (baudrate > (busClkHz/20U))
    {
        return 0U;
    }
    for (mult = 0u; (mult <= 2u) && (bestError != 0); ++mult)
    {
        uint32_t multiplier = 1u << mult;
        /* scan table to find best match. */
        uint32_t i;
        for (i = 0u; i < sizeof(I2C_DiverTable)/sizeof(I2C_DiverTable[0]); ++i)
        {
            uint32_t computedRate = busClkHz / (multiplier * I2C_DiverTable[i].sclDivider);
            uint32_t absError = hz > computedRate ? hz - computedRate : computedRate - hz;
            if (absError < bestError)
            {
                bestMult = mult;
                bestIcr = I2C_DiverTable[i].icr;
                bestError = absError;
                /* If the error is 0, then we can stop searching because we won't find a
                 better match.*/
                if (absError == 0)
                {
                    break;
                }
            }
        }
    }
    return (I2C_F_ICR(bestIcr)|I2C_F_MULT(bestMult));
}

bool I2C_Init(uint32_t instance, const i2c_config_t *configPtr)
{
    if (!configPtr)
    {
        return false;
    }
    I2C_SetUnGateCmd(instance, true);
    
    g_I2cBasePtr[instance]->C1 = 0U; /* Disable all the switchers. */
    g_I2cBasePtr[instance]->F = I2C_CalcBaudrate(configPtr->BusClkHz, configPtr->Baudrate);
    
    
    g_I2cBasePtr[instance]->C1 = I2C_C1_IICEN_MASK; /* Enable I2C. */
    
    return true;
}

void I2C_SendAck(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 &= ~I2C_C1_TXAK_MASK;
}

void I2C_SendNAck(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 |= I2C_C1_TXAK_MASK;
}

void I2C_SetTxMode(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 |= I2C_C1_TX_MASK;
}

void I2C_SetRxMode(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 &= ~I2C_C1_TX_MASK;
}

static void I2C_SetMasterMode(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 |= I2C_C1_MST_MASK;
}

static void I2C_SetSlaveMode(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 &= ~I2C_C1_MST_MASK;
}

void I2C_Start(uint32_t instance)
{
    I2C_SetMasterMode(instance);
    I2C_SetTxMode(instance);
}

void I2C_Stop(uint32_t instance)
{
    I2C_SetSlaveMode(instance);
    I2C_SetRxMode(instance);
}

void I2C_Restart(uint32_t instance)
{
    g_I2cBasePtr[instance]->C1 |= I2C_C1_RSTA_MASK;
}

void I2C_PutByte(uint32_t instance, uint8_t ch)
{
    g_I2cBasePtr[instance]->D = ch;
}

uint8_t I2C_GetByte(uint32_t instance)
{
    return g_I2cBasePtr[instance]->D;
}

/* I2C_WaitAck. */
void I2C_WaitAck(uint32_t instance)
{
    /* wait flag */
    while(!(g_I2cBasePtr[instance]->S & I2C_S_IICIF_MASK))
    {}
    /* clear flag */
    g_I2cBasePtr[instance]->S |= I2C_S_IICIF_MASK;
}

bool I2C_GetAck(uint32_t instance)
{
    return ((g_I2cBasePtr[instance]->S & I2C_S_RXAK_MASK) == 0U);
}

bool I2C_IsBusy(uint32_t instance)
{
    return (0U != (g_I2cBasePtr[instance]->S & I2C_S_BUSY_MASK) );
}

void I2C_ReadBytes(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t *rxBufPtr, /* Pointer to the reading stream. */
                   uint32_t rxLen     /* Length of the reading stream. */
)
{
    uint32_t i;
    
    I2C_Start(instance);
    
    /* Send Address. */
    I2C_PutByte(instance, devAddr | I2C_WRITE_CMD);
    I2C_WaitAck(instance);
    
    /* Send Reg Address. */
    I2C_PutByte(instance, regAddr);
    I2C_WaitAck(instance);
    
    /* Restart to read Address. */
    I2C_Restart(instance);
    I2C_PutByte(instance, devAddr | I2C_READ_CMD);
    I2C_WaitAck(instance);
    
    I2C_SetRxMode(instance);
    
    /* Dummy Read. */
    I2C_GetByte(instance);
    I2C_SendAck(instance);
    I2C_WaitAck(instance);
    
    /* Real Read. */
    for (i = 0U; i<(rxLen-1U); i++)
    {
        *rxBufPtr++ = I2C_GetByte(instance);
        I2C_SendAck(instance);
        I2C_WaitAck(instance);
    }
    /* Read the last byte. */
    *rxBufPtr = I2C_GetByte(instance);
    I2C_SendNAck(instance);
    I2C_WaitAck(instance);
    
    I2C_Stop(instance);
    
    while (I2C_IsBusy(instance));
}

void I2C_WriteBytes(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t *txBufPtr, /* Pointer to the writing stream. */
                   uint32_t txLen     /* Length of the writing stream. */
)
{
    uint32_t i;
    
    I2C_Start(instance);
    
    /* Send device address. */
    I2C_PutByte(instance, devAddr | I2C_WRITE_CMD);
    I2C_WaitAck(instance);
    
    /* Send register address. */
    I2C_PutByte(instance, regAddr);
    I2C_WaitAck(instance);
    
    /* Send data. */
    for (i = 0U; i < txLen; i++)
    {
        I2C_PutByte(instance, txBufPtr[i]);
        I2C_WaitAck(instance);
    }
    
    I2C_Stop(instance);
    while (I2C_IsBusy(instance));
}

void I2C_WriteByte(uint32_t instance, /* I2C instance. */
                    uint8_t devAddr,  /* Target device address. */
                    uint8_t regAddr,  /* Register address in target device. */
                    uint8_t txByte    /* Byte to write. */
)
{
    I2C_WriteBytes(instance, devAddr, regAddr, &txByte, 1U);
}
