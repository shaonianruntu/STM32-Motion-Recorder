/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_timer.c
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for TAU module.
* Creation Date: 2015/3/31
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
#pragma interrupt INTTM00 r_tau0_channel0_interrupt
#pragma interrupt INTTM01 r_tau0_channel1_interrupt

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_macrodriver.h"
#include "r_timer.h"
#include "r_userdefine.h"
#include "r_ADXL362.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
extern unsigned char status;
extern short         xAxis;
extern short         yAxis;
extern short         zAxis;

extern  unsigned char step1_flag;
extern  unsigned char step2_flag;

extern uint16_t g_Step;
extern uint8_t g_Weight;
extern uint8_t g_Length;
extern uint16_t g_Calorie;

uint16_t old_step = 0U;
uint16_t step_2s = 0U;

/***********************************************************************************************************************
* Function Name: R_TAU0_Create
* Description  : This function initializes the TAU0 module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_TAU0_Create(void)
{
    TAU0EN = 1U;    /* supplies input clock */
    TPS0 = 0x0093U;
    /* Stop all channels */
    TT0 = 0x0AFFU;
    /* Mask channel 0 interrupt */
    TMMK00 = 1U;    /* disable INTTM00 interrupt */
    TMIF00 = 0U;    /* clear INTTM00 interrupt flag */
    /* Mask channel 1 interrupt */
    TMMK01 = 1U;    /* disable INTTM01 interrupt */
    TMIF01 = 0U;    /* clear INTTM01 interrupt flag */
    /* Mask channel 1 higher 8 bits interrupt */
    TMMK01H = 1U;    /* disable INTTM01H interrupt */
    TMIF01H = 0U;    /* clear INTTM01H interrupt flag */
    /* Mask channel 2 interrupt */
    TMMK02 = 1U;    /* disable INTTM02 interrupt */
    TMIF02 = 0U;    /* clear INTTM02 interrupt flag */
    /* Mask channel 3 interrupt */
    TMMK03 = 1U;    /* disable INTTM03 interrupt */
    TMIF03 = 0U;    /* clear INTTM03 interrupt flag */
    /* Mask channel 3 higher 8 bits interrupt */
    TMMK03H = 1U;    /* disable INTTM03H interrupt */
    TMIF03H = 0U;    /* clear INTTM03H interrupt flag */

    /* Mask channel 6 interrupt */
    TMMK06 = 1U;    /* disable INTTM06 interrupt */
    TMIF06 = 0U;    /* clear INTTM06 interrupt flag */
    /* Mask channel 7 interrupt */
    TMMK07 = 1U;    /* disable INTTM07 interrupt */
    TMIF07 = 0U;    /* clear INTTM07 interrupt flag */
    /* Set INTTM00 low priority */
    TMPR100 = 1U;
    TMPR000 = 1U;
    /* Set INTTM01 low priority */
    TMPR101 = 1U;
    TMPR001 = 1U;
    /* Channel 0 used as interval timer */
    TMR00 = 0x0000U;
    TDR00 = 0x9C3FU;
    TO0 &= ~0x0001U;
    TOE0 &= ~0x0001U;
    /* Channel 1 used as interval timer */
    TMR01 = 0x8000U;
    TDR01 = 0xF423U;
    TOM0 &= ~0x0002U;
    TOL0 &= ~0x0002U;
    TO0 &= ~0x0002U;
    TOE0 &= ~0x0002U;
}
/***********************************************************************************************************************
End of function R_TAU0_Create
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_TAU0_Channel0_Start
* Description  : This function starts TAU0 channel 0 counter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_TAU0_Channel0_Start(void)
{  
    TMIF00 = 0U;    /* clear INTTM00 interrupt flag */
    TMMK00 = 0U;    /* enable INTTM00 interrupt */
    TS0 |= 0x0001U;
}
/***********************************************************************************************************************
End of function R_TAU0_Channel0_Start
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_TAU0_Channel1_Start
* Description  : This function starts TAU0 channel 1 counter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_TAU0_Channel1_Start(void)
{  
    TMIF01 = 0U;    /* clear INTTM01 interrupt flag */
    TMMK01 = 0U;    /* enable INTTM01 interrupt */
    TS0 |= 0x0002U;
}
/***********************************************************************************************************************
End of function R_TAU0_Channel1_Start
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: r_tau0_channel0_interrupt
* Description  : This function is INTTM00 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void r_tau0_channel0_interrupt(void)
{

    ADXL362_GetXyz(&xAxis, &yAxis, &zAxis);
    if(xAxis > 1200)
        step1_flag = 1;
    if((xAxis < 1100) && (step1_flag == 1))
        step2_flag = 1;
        
    if((step1_flag == 1) && (step2_flag == 1))
    {
        g_Step = adbcdw(g_Step, 1);
        step1_flag = 0;
        step2_flag = 0;
    }
}
/***********************************************************************************************************************
End of function r_tau0_channel0_interrupt
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: r_tau0_channel1_interrupt
* Description  : This function is INTTM01 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
__interrupt static void r_tau0_channel1_interrupt(void)
{
    step_2s = sbbcdw(g_Step,old_step );
    g_Calorie = bcdtow ( g_Calorie );
    g_Length = bcdtob (g_Length);
    g_Weight = bcdtob (g_Weight);
    g_Calorie +=  (step_2s * g_Length * g_Weight /200);
    g_Calorie = wtobcd ( g_Calorie );
    g_Weight = btobcd ( g_Weight );
    g_Length = btobcd (g_Length);

    step_2s = 0;
    old_step = g_Step;
}
/***********************************************************************************************************************
End of function r_tau0_channel1_interrupt
***********************************************************************************************************************/
