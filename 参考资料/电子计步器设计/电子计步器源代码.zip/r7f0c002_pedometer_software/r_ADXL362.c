/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ADXL362.c
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for ADXL362.
* Creation Date: 2015/3/31
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_macrodriver.h"
#include "r_ADXL362.h"
#include "r_Communication.h"

/***********************************************************************************************************************
* Function Name: ADXL362_Init
* Description  : This function initializes communication with the device and checks if the part is present by reading 
*                the device id.
* Arguments    : None
* Return Value : 1 if the initialization was successful and the device is present,
*                0 if an error occurred.
***********************************************************************************************************************/
unsigned char ADXL362_Init(void)
{
    unsigned char regValue = 0U;
    unsigned char status   = 0U;

    status = SPI_Init(0, 4000000, 0, 1);
    ADXL362_GetRegisterValue(&regValue, 0x02, 1);
    if((ADXL362_PART_ID != regValue))
    {
        status = 0U;
    }

    return status;
}
/***********************************************************************************************************************
End of function ADXL362_Init
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetRegisterValue
* Description  : This function Writes data into a register of ADXL362.
* Arguments    : registerValue - Data value to write.
*                registerAddress - Address of the register.
*                bytesNumber - Number of bytes. Accepted values: 0 - 1.
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetRegisterValue(unsigned short registerValue,
                              unsigned char  registerAddress,
                              unsigned char  bytesNumber)
{
    unsigned char buffer[4] = {0, 0, 0, 0};

    buffer[0] = ADXL362_WRITE_REG;
    buffer[1] = registerAddress;
    buffer[2] = (unsigned char)(registerValue & 0x00FF);
    buffer[3] = (unsigned char)(registerValue >> 8);
    SPI_Write(ADXL362_SLAVE_ID, buffer, bytesNumber + 2);
}
/***********************************************************************************************************************
End of function ADXL362_SetRegisterValue
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_GetRegisterValue
* Description  : This function performs a burst read of a specified number of ADXL362 registers..
* Arguments    : pReadData - The read values are stored in this buffer.
*                registerAddress - The start address of the burst read.
*                bytesNumber - Number of bytes to read.
* Return Value : None
***********************************************************************************************************************/
void ADXL362_GetRegisterValue(unsigned char* pReadData,
                              unsigned char  registerAddress,
                              unsigned char  bytesNumber)
{
    unsigned char buffer[32];
    unsigned char index = 0U;
    
    buffer[0] = ADXL362_READ_REG;
    buffer[1] = registerAddress;
    for(index = 0U; index < bytesNumber; index++)
    {
        buffer[index + 2] = pReadData[index];
    }
    SPI_Read(ADXL362_SLAVE_ID, buffer, bytesNumber + 2);
    for(index = 0U; index < bytesNumber; index++)
    {
        pReadData[index] = buffer[index + 2];
    }
}
/***********************************************************************************************************************
End of function ADXL362_GetRegisterValue
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SoftwareReset
* Description  : This function resets the device via SPI communication bus.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SoftwareReset(void)
{
    ADXL362_SetRegisterValue(ADXL362_RESET_KEY, ADXL362_REG_SOFT_RESET, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SoftwareReset
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetPowerMode
* Description  : This function places the ADXL362 into standby/measure mode.
* Arguments    : pwrMode - Power mode.
*                Example: 0 - standby mode.
*                         1 - measure mode.
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetPowerMode(unsigned char pwrMode)
{
    unsigned char oldPowerCtl = 0U;
    unsigned char newPowerCtl = 0U;

    ADXL362_GetRegisterValue(&oldPowerCtl, ADXL362_REG_POWER_CTL, 1);
    newPowerCtl = oldPowerCtl & ~ADXL362_POWER_CTL_MEASURE(0x3);
    newPowerCtl = newPowerCtl |
                  (pwrMode * ADXL362_POWER_CTL_MEASURE(ADXL362_MEASURE_ON));
    ADXL362_SetRegisterValue(newPowerCtl, ADXL362_REG_POWER_CTL, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SetPowerMode
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetRange
* Description  : This function selects the measurement range.
* Arguments    : gRange - Range option.
*                Example: ADXL362_RANGE_2G  -  +-2 g
*                         ADXL362_RANGE_4G  -  +-4 g
*                         ADXL362_RANGE_8G  -  +-8 g
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetRange(unsigned char gRange)
{
    unsigned char oldFilterCtl = 0U;
    unsigned char newFilterCtl = 0U;

    ADXL362_GetRegisterValue(&oldFilterCtl, ADXL362_REG_FILTER_CTL, 1);
    newFilterCtl = (unsigned char) (oldFilterCtl & ~ADXL362_FILTER_CTL_RANGE(0x3U));
    newFilterCtl = (unsigned char) (newFilterCtl | ADXL362_FILTER_CTL_RANGE(gRange));
    ADXL362_SetRegisterValue(newFilterCtl, ADXL362_REG_FILTER_CTL, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SetRange
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetOutputRate
* Description  : This function selects the Output Data Rate of the device.
* Arguments    : outRate - Output Data Rate option.
*                Example: ADXL362_ODR_12_5_HZ  -  12.5Hz
*                         ADXL362_ODR_25_HZ    -  25Hz
*                         ADXL362_ODR_50_HZ    -  50Hz
*                         ADXL362_ODR_100_HZ   -  100Hz
*                         ADXL362_ODR_200_HZ   -  200Hz
*                         ADXL362_ODR_400_HZ   -  400Hz
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetOutputRate(unsigned char outRate)
{
    unsigned char oldFilterCtl = 0U;
    unsigned char newFilterCtl = 0U;

    ADXL362_GetRegisterValue(&oldFilterCtl, ADXL362_REG_FILTER_CTL, 1);
    newFilterCtl = oldFilterCtl & ~ADXL362_FILTER_CTL_ODR(0x7);
    newFilterCtl = newFilterCtl | ADXL362_FILTER_CTL_ODR(outRate);
    ADXL362_SetRegisterValue(newFilterCtl, ADXL362_REG_FILTER_CTL, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SetOutputRate
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_GetXyz
* Description  : This function reads the 3-axis raw data from the accelerometer.
* Arguments    : x - Stores the X-axis data(as two's complement).
*                y - Stores the X-axis data(as two's complement).
*                z - Stores the X-axis data(as two's complement).
* Return Value : None
***********************************************************************************************************************/
void ADXL362_GetXyz(short* x, short* y, short* z)
{
    unsigned char xyzValues[6] = {0, 0, 0, 0, 0, 0};

    ADXL362_GetRegisterValue(xyzValues, ADXL362_REG_XDATA_L, 6U);
    *x = (((short)xyzValues[1] << 8U) + xyzValues[0]);
    *y = (((short)xyzValues[3] << 8U) + xyzValues[2]);
    *z = (((short)xyzValues[5] << 8U) + xyzValues[4]);
}
/***********************************************************************************************************************
End of function ADXL362_GetXyz
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_ReadTemperature
* Description  : This function reads the temperature of the device.
* Arguments    : None
* Return Value : tempCelsius - The value of the temperature(degrees Celsius).
***********************************************************************************************************************/
float ADXL362_ReadTemperature(void)
{
    unsigned char rawTempData[2] = {0, 0};
    short         signedTemp     = 0U;
    float         tempCelsius    = 0U;

    ADXL362_GetRegisterValue(rawTempData, ADXL362_REG_TEMP_L, 2);
    signedTemp = (short)(rawTempData[1] << 8U) + rawTempData[0];
    tempCelsius = (float)(signedTemp + 350) * 0.065;

    return tempCelsius;
}
/***********************************************************************************************************************
End of function ADXL362_ReadTemperature
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetupActivityDetection
* Description  : This function configures activity detection.
* Arguments    : refOrAbs - Referenced/Absolute Activity Select.
*                Example: 0 - absolute mode.
*                         1 - referenced mode.refOrAbs 
*                threshold - 11-bit unsigned value that the adxl362 samples are compared to.
*                time - 16-bit value written to the inactivity timer register. The amount of time 
*                (in seconds) is: time / ODR, where ODR - is the output  data rate.
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetupActivityDetection(unsigned char  refOrAbs,
                                    unsigned short threshold,
                                    unsigned char  time)
{
    unsigned char oldActInactReg = 0U;
    unsigned char newActInactReg = 0U;

    /* Configure motion threshold and activity timer. */
    ADXL362_SetRegisterValue((threshold & 0x7FF), ADXL362_REG_THRESH_ACT_L, 2);
    ADXL362_SetRegisterValue(time, ADXL362_REG_TIME_ACT, 1);
    /* Enable activity interrupt and select a referenced or absolute
       configuration. */
    ADXL362_GetRegisterValue(&oldActInactReg, ADXL362_REG_ACT_INACT_CTL, 1);
    newActInactReg = oldActInactReg & ~ADXL362_ACT_INACT_CTL_ACT_REF;
    newActInactReg |= ADXL362_ACT_INACT_CTL_ACT_EN |
                     (refOrAbs * ADXL362_ACT_INACT_CTL_ACT_REF);
    ADXL362_SetRegisterValue(newActInactReg, ADXL362_REG_ACT_INACT_CTL, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SetupActivityDetection
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: ADXL362_SetupInactivityDetection
* Description  : This function configures inactivity detection..
* Arguments    : refOrAbs - Referenced/Absolute Inactivity Select.
*                   Example: 0 - absolute mode.
*                            1 - referenced mode.
*                threshold - 11-bit unsigned value that the adxl362 samples are compared to.
*                time - 16-bit value written to the inactivity timer register. The amount of time 
*                (in seconds) is: time / ODR, where ODR - is the output  data rate.
* Return Value : None
***********************************************************************************************************************/
void ADXL362_SetupInactivityDetection(unsigned char  refOrAbs,
                                      unsigned short threshold,
                                      unsigned short time)
{
    unsigned char oldActInactReg = 0U;
    unsigned char newActInactReg = 0U;
    
    /* Configure motion threshold and inactivity timer. */
    ADXL362_SetRegisterValue((threshold & 0x7FF),
                              ADXL362_REG_THRESH_INACT_L,
                              2);
    ADXL362_SetRegisterValue(time, ADXL362_REG_TIME_INACT_L, 2);
    /* Enable inactivity interrupt and select a referenced or absolute
       configuration. */
    ADXL362_GetRegisterValue(&oldActInactReg, ADXL362_REG_ACT_INACT_CTL, 1);
    newActInactReg = oldActInactReg & ~ADXL362_ACT_INACT_CTL_INACT_REF;
    newActInactReg |= ADXL362_ACT_INACT_CTL_INACT_EN |
                     (refOrAbs * ADXL362_ACT_INACT_CTL_INACT_REF);
    ADXL362_SetRegisterValue(newActInactReg, ADXL362_REG_ACT_INACT_CTL, 1);
}
/***********************************************************************************************************************
End of function ADXL362_SetupInactivityDetection
***********************************************************************************************************************/
