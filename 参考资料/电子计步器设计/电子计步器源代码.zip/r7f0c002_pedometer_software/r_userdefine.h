/******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
******************************************************************************/
/******************************************************************************
* File Name    : r_userdefine.h
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file includes user definition.
* Creation Date: 2015/3/31
******************************************************************************/

/******************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
******************************************************************************/

#ifndef _MD_USER_DEF_
#define _MD_USER_DEF_

/******************************************************************************
Macro definitions
******************************************************************************/
#define LCD_CUSTOMER        1

#define LCD_POSITION_HOUR_HIGH           (&SEG0)    /* Display start position(tens place of hour data) */
#define LCD_POSITION_HOUR_LOW            (&SEG2)    /* Display start position(ones place of hour data) */
#define LCD_POSITION_COLON_LOW           (&SEG16)   /* Display start position(colon) */
#define LCD_POSITION_MINUTE_HIGH         (&SEG4)    /* Display start position(tens place of minute data) */
#define LCD_POSITION_MINUTE_LOW          (&SEG6)    /* Display start position(ones place of minute data) */

#if LCD_CUSTOMER
#define LCD_DATA_0                       (0x070D)    /* LCD Data(0) */
#define LCD_DATA_1                       (0x0600)    /* LCD Data(1) */
#define LCD_DATA_2                       (0x030E)    /* LCD Data(2) */
#define LCD_DATA_3                       (0x070A)    /* LCD Data(3) */
#define LCD_DATA_4                       (0x0603)    /* LCD Data(4) */
#define LCD_DATA_5                       (0x050B)    /* LCD Data(5) */
#define LCD_DATA_6                       (0x050F)    /* LCD Data(6) */
#define LCD_DATA_7                       (0x0700)    /* LCD Data(7) */
#define LCD_DATA_8                       (0x070F)    /* LCD Data(8) */
#define LCD_DATA_9                       (0x070B)    /* LCD Data(9) */
#define LCD_DATA_COLON                   (0x04)      /* LCD Data(colon) */
#else
#define LCD_DATA_0                       (0x0A0F)    /* LCD Data(0) */
#define LCD_DATA_1                       (0x0006)    /* LCD Data(1) */
#define LCD_DATA_2                       (0x060D)    /* LCD Data(2) */
#define LCD_DATA_3                       (0x040F)    /* LCD Data(3) */
#define LCD_DATA_4                       (0x0C06)    /* LCD Data(4) */
#define LCD_DATA_5                       (0x0C0B)    /* LCD Data(5) */
#define LCD_DATA_6                       (0x0E0B)    /* LCD Data(6) */
#define LCD_DATA_7                       (0x080E)    /* LCD Data(7) */
#define LCD_DATA_8                       (0x0E0F)    /* LCD Data(8) */
#define LCD_DATA_9                       (0x0C0F)    /* LCD Data(9) */
#define LCD_DATA_COLON                   (0x02)      /* LCD Data(colon) */
#endif


#define LCD_DATA_NONE                    (0x0000)    /* LCD Data(none) */
#define INTERRUPT_OFF                    (0x00)      /* Interruption factor parameter(none) */
#define INTRC_ON                         (0x01)      /* Interruption factor parameter(INTRTC) */
#define INTPN_ON                         (0x02)      /* Interruption factor parameter(INTP) */
#define LCD_NUM_DATA_SIZE                (0x02)      /* Size of LCD data */
#define LCD_COLON_DATA_SIZE              (0x01)      /* Size of colon data */
#define LCD_NUM_DATA_FONT_COUNT          (0x0C)      /* Number of LCD data */
#define LCD_DATA_NONE_INDEX              (0x0A)      /* Index of none-data */
#define LCD_DATA_COLON_INDEX             (0x0B)      /* Index of colon data */
#define WATCH_DISPLAY                    (0x00)      /* Display status(time display) */
#define HOUR_ADJUST                      (0x01)      /* Display status(hour adjust) */
#define MINUTE_ADJUST                    (0x02)      /* Display status(minute adjust) */

#define WEIGHT_DISPLAY                   (0x00)      /* Display status(time display) */
#define WEIGHT_ADJUST                    (0x01)      /* Display status(hour adjust) */


#define SET_SWITCH_ON                    (0x01)      /* Switch status(SET) */
#define UP_SWITCH_ON                     (0x02)      /* Switch status(UP) */
#define DOWN_SWITCH_ON                   (0x03)      /* Switch status(SET) */
#define TRANS_SWITCH_ON                  (0x04)      /* Switch status(UP) */
#define SWITCH_ALL_OFF                   (0x00)      /* Switch status(NONE) */
#define LCD_DISPLAY_NORMAL               (0x00)      /* LCD display status(normal) */
#define LCD_DISPLAY_BLINK                (0x01)      /* LCD display status(blink) */

/******************************************************************************
Exported global functions (to be accessed by other files)
******************************************************************************/
uint8_t R_MAIN_Get_SwitchStatus(void);
void R_MAIN_LcdHourBlink(void);
void R_MAIN_LcdMinuteBlink(void);
void R_MAIN_LcdDisplayNormal(void);

void R_MAIN_LcdWeightBlink(void);
void R_MAIN_LcdLengthBlink(void);

void R_MAIN_LcdStepDisplayNormal(void);
void R_MAIN_LcdCalorieDisplayNormal(void);
void R_MAIN_LcdLastStepDisplayNormal(void);

void R_MAIN_LcdDisplayWeight(void);
void R_MAIN_Delay1ms(uint8_t time);
#endif