/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_lcd.c
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file implements device driver for LCD module.
* Creation Date: 2015/3/31
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_macrodriver.h"
#include "r_lcd.h"
#include "r_userdefine.h"

/***********************************************************************************************************************
* Function Name: R_LCD_Create
* Description  : This function initializes the LCD module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_LCD_Create(void)
{
    volatile uint32_t wt_count;
    
    LCDON = 0U;                         /* disable LCD clock operation */
    LCDM1 |= 0x11U;
    LCDM0 |= 0x4DU;
    /* Set CAPL and CAPH pins */
    ISCLCD &= 0x02U;
    
    /* Set segment pins */
    ADPC = 0x01U;
    PFSEG0 |= 0xF0U;
    PFSEG2 |= 0x07U;
    PFSEG3 |= 0x00U;
    PFSEG4 |= 0x00U;
    POM1 &= 0x5FU;
    PIM1 &= 0x9FU;
    PU1 &= 0x1FU;
    P1 &= 0x1FU;
    PM1 &= 0x1FU;
    PU3 &= 0xF9U;
    P3 &= 0xF9U;
    PM3 &= 0xF9U;
    PU5 &= 0xFEU;
    P5 &= 0xFEU;
    PM5 &= 0xFEU;
    PU7 &= 0xFEU;
    P7 &= 0xFEU;
    PM7 &= 0xFEU;

    LCDC0 = 0x06U;                      /* fSUB/2^7 or fIL/2^7 */
    VLCD = 0x04U;                       /* 1.00 V (1/3 bias: 3.00 V; 1/4 bias: 4.00 V) */
}
/***********************************************************************************************************************
End of function R_LCD_Create
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_LCD_Start
* Description  : This function enables the LCD display.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_LCD_Start(void)
{
    volatile uint32_t wt_count;
    
    VLCON = 1U;
    for(wt_count = 0U; wt_count < 6000U; wt_count++)
    {
        /* Do nothing */
    }
    
    LCDM1 |= 0xC0U;
}
/***********************************************************************************************************************
End of function R_LCD_Start
***********************************************************************************************************************/
