/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_Communication.c
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file implementation of Communication Driver for R7F0C002.
* Creation Date: 2015/3/31
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_macrodriver.h"
#include "r_Communication.h"

/***********************************************************************************************************************
* Function Name: SPI_Init
* Description  : This function initializes the SPI communication peripheral.
* Arguments    : lsbFirst - Transfer format (0 or 1).
*                clockFreq - SPI clock frequency (Hz).
*                clockPol - SPI clock polarity (0 or 1).
*                clockEdg - SPI clock edge (0 or 1).
* Return Value : status - Result of the initialization procedure.
*                Example: 1 - if initialization was successful;
*                         0 - if initialization was unsuccessful.
***********************************************************************************************************************/
unsigned char SPI_Init(unsigned char lsbFirst,
                       unsigned long clockFreq,
                       unsigned char clockPol,
                       unsigned char clockEdg)
{
    unsigned long mckFreq  = 16000000U;
    unsigned char sdrValue = 0U;

    /* Configure the CS pins. */
    PM1 &= ~(0x08);               //P13 as CS of 362 output high
    P1 |= 0x08U;

    /* Enable input clock supply. */
    SAU0EN = 1U;
    /* After setting the SAUmEN bit to 1, be sure to set serial clock select
       register m (SPSm) after 4 or more fCLK clocks have elapsed. */
    NOP();
    NOP();
    NOP();
    NOP();

 /* Select the fCLK as input clock.  */
    SPS0 = 0x0001U;

    /* Select the CSI operation mode. */
    SMR00 = 0x0020U;

    clockPol = 1 - clockPol;
    SCR00 = (clockEdg << 13) |
            (clockPol << 12) |
            0xC000 |            // Operation mode: Transmission/reception.
            0x0007;             // 8-bit data length (stored in bits 0 to 7 of
                                // the SDRmn register).


    /* clockFreq =  mckFreq / (sdrValue * 2 + 2)*/
    sdrValue = (unsigned char)(mckFreq / (2 * clockFreq) - 1);
    SDR00 = sdrValue << 9;

    /* Set the clock and data initial level. */
    clockPol = 1 - clockPol;
    SO0 &= ~0x0101;
    SO0 |= (clockPol << 8) |
           (clockPol << 0);

    /* Enable output for serial communication operation. */
    SOE0 |= 0x0001;

    /* Set SI00 pin */
    PFSEG3 &= 0xDFU;
    PM1 |= 0x02U;
    /* Set SO00 pin */
    PFSEG3 &= 0xBFU;
    P1 |= 0x04U;
    PM1 &= 0xFBU;
    /* Set SCK00 pin */
    PFSEG3 &= 0xEFU;
    P1 |= 0x01U;
    PM1 &= 0xFEU;

    /* Set the SEmn bit to 1 and enter the communication wait status */
    SS0 |= 0x0001U;
    
    return 1;
}
/***********************************************************************************************************************
End of function SPI_Init
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: SPI_Read
* Description  : This function reads data from SPI. 
* Arguments    : slaveDeviceId - The ID of the selected slave device.
*                data - Data represents the write buffer as an input parameter and the read buffer as an output parameter.
*                bytesNumber - Number of bytes to read.
* Return Value : Number of read bytes.
***********************************************************************************************************************/
unsigned char SPI_Read(unsigned char slaveDeviceId,
                       unsigned char* data,
                       unsigned char bytesNumber)
{
    unsigned char byte = 0U;

    if(1U == slaveDeviceId)
    {
        P1 &= ~0x08;
    }
    for(byte = 0U; byte < bytesNumber; byte++)
    {
        SIO00 = data[byte];
        NOP();
        NOP();
        while(SSR00 & 0x0040U);
        data[byte] = SIO00;
    }
    if(1U == slaveDeviceId)
    {
        P1 |= 0x08U;
    }
    
    return bytesNumber;
}
/***********************************************************************************************************************
End of function SPI_Read
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: SPI_Write
* Description  : This function writes data to SPI.
* Arguments    : slaveDeviceId - The ID of the selected slave device.
 *               data - Data represents the write buffer.
 *               bytesNumber - Number of bytes to write.
* Return Value :  Number of written bytes.
***********************************************************************************************************************/
unsigned char SPI_Write(unsigned char slaveDeviceId,
                        unsigned char* data,
                        unsigned char bytesNumber)
{
    unsigned char byte = 0U;
    unsigned char read = 0U;
    
    if(1U == slaveDeviceId)
    {
        P1 &= ~0x08;
    }
    for(byte = 0U; byte < bytesNumber; byte++)
    {
        SIO00 = data[byte];
        NOP();
        NOP();
        while(SSR00 & 0x0040U);
        read = SIO00;
    }
    if(1U == slaveDeviceId)
    {
        P1 |= 0x08U;
    }
    return bytesNumber;
}
/***********************************************************************************************************************
End of function SPI_Write
***********************************************************************************************************************/