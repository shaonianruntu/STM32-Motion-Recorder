/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_main.c
* Version      : V1.00
* Device(s)    : R7F0C002G2DFB
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 2015/3/31
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
* : 31.03.2015 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , <Project Includes>
***********************************************************************************************************************/
#include "r_macrodriver.h"
#include "r_cgc.h"
#include "r_port.h"
#include "string.h"
#include "r_lcd.h"
#include "r_rtc.h"
#include "r_timer.h"
#include "r_userdefine.h"
#include "r_Communication.h"
#include "r_ADXL362.h"


#include "pfdl.h"
#include "pfdl_types.h"
/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
static uint16_t g_FontData[LCD_NUM_DATA_FONT_COUNT] = { LCD_DATA_0, LCD_DATA_1, LCD_DATA_2, LCD_DATA_3, LCD_DATA_4,
                                                        LCD_DATA_5, LCD_DATA_6, LCD_DATA_7, LCD_DATA_8, LCD_DATA_9,
                                                        LCD_DATA_NONE, LCD_DATA_COLON };

static uint8_t g_WatchStatus;
static uint8_t g_WeightStatus;
static uint8_t g_Hour;
static uint8_t g_Minute;
uint8_t g_Weight = 0x40U;
uint8_t g_Length = 0x70U;
uint16_t g_Step;
uint16_t g_Step_last;

uint8_t Count_flag = 0U;

uint8_t g_Step_temp1[2] = {0x00,0x00};
uint8_t g_Step_temp2[2] = {0x00,0x00};

uint16_t g_Calorie;
uint8_t set_flag = 0U;

uint8_t step1_flag = 0U;
uint8_t step2_flag = 0U;

uint8_t switch_status      = 0U;
uint8_t status             = 0U;
short         xAxis        = 0U;
short         yAxis        = 0U;
short         zAxis        = 0U;
float         temperature  = 0U;
pfdl_u16 StartAddrIndex    = 0U;

#define FALSE    0
#define TRUE     1
#define BLOCKBYTES 1024

void R_MAIN_UserInit(void);
pfdl_u08 Write_DataFlash(void);
pfdl_u08 Read_DataFlash(void);
pfdl_u08 Erase_DataFlash(pfdl_u16 block);
/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    uint8_t set_count = 0U;
    uint8_t count = 0U;
    rtc_counter_value_t time_data;
    g_Hour = 0x00U;
    g_Minute = 0x00U;
    
    R_MAIN_UserInit();

    Read_DataFlash();
    g_Step_last = (((short)g_Step_temp2[1] << 8) + g_Step_temp2[0]);
    if(0xFFFFU == g_Step_last)
        g_Step_last = 0U;

    while(1U)
    {
        switch_status = R_MAIN_Get_SwitchStatus();

        if((0x23U == HOUR) && (0x59U == MIN) && (0x59U == SEC)&& (1U == RIFG))
        {
            DI();
            RIFG = 0U;
            g_Step_temp1[0] = (uint8_t)(g_Step & 0x00ff);
            g_Step_temp1[1] = (uint8_t)((g_Step >> 8) & 0x00ff);

            Write_DataFlash();
            g_Step = 0U;
            g_Calorie = 0U;
            Read_DataFlash();
            g_Step_last = (((short)g_Step_temp2[1] << 8) + g_Step_temp2[0]);
            EI();
        }

        if(0U == set_flag)
        {
            switch(count)
            {
                case 0:
                {
                    R_RTC_Get_CounterValue(&time_data);
                    g_Hour = time_data.hour;
                    g_Minute = time_data.min;
                    /* ---- Time displays on LCD ---- */
                    R_MAIN_LcdDisplayNormal();
                }
                break;
                
                case 1:
                {
                    /* ---- Steps displays on LCD ---- */
                    R_MAIN_LcdStepDisplayNormal();
                }
                break;
                    
                case 2:
                {
                    
                    /* ---- Carlorie displays on LCD ---- */
                    R_MAIN_LcdCalorieDisplayNormal();
                }
                break;
                
                case 3:
                {
                    /* ---- Last Steps displays on LCD ---- */
                    R_MAIN_LcdLastStepDisplayNormal();
                }
                break;
                default:
                break;
            }
            if(switch_status == TRANS_SWITCH_ON)
            {
                count++;
                if(4U == count)
                count = 0U;
            }
        }

        else if(1U == set_flag)
        {
            switch(set_count)
            {
                case 0 :
                {
                    R_MAIN_LcdHourBlink();
                    if(UP_SWITCH_ON == switch_status)
                    {
                        g_Hour = adbcdb(g_Hour, 1U);
                        /* ---- When hour data is 0x24 ---- */
                        if (0x24U == g_Hour)
                        {
                            g_Hour = 0x00U;
                        }
                        time_data.hour = g_Hour;
                        R_RTC_Set_CounterValue(time_data);
                    }
                    else if(DOWN_SWITCH_ON == switch_status)
                    {
                        g_Hour = sbbcdb(g_Hour, 1U);
                        if (0x99U == g_Hour)
                        {
                            g_Hour = 0x23U;
                        }
                        time_data.hour = g_Hour;
                        R_RTC_Set_CounterValue(time_data);
                    }
                }
                break;
                
                case 1 :
                {
                    R_MAIN_LcdMinuteBlink();
                    if(UP_SWITCH_ON == switch_status)
                    {
                        g_Minute = adbcdb(g_Minute, 1U);
                        /* ---- When hour data is 0x24 ---- */
                        if (0x60U == g_Minute)
                        {
                            g_Minute = 0x00U;
                        }
                        time_data.min = g_Minute;
                        R_RTC_Set_CounterValue(time_data);
                    }
                    else if(DOWN_SWITCH_ON == switch_status)
                    {
                        g_Minute = sbbcdb(g_Minute, 1U);
                        /* ---- When hour data is 0x24 ---- */
                        if (0x99U == g_Minute)
                        {
                            g_Minute = 0x59U;
                        }
                        time_data.min = g_Minute;
                        R_RTC_Set_CounterValue(time_data);
                    }
                    
                }
                break;
                
                case 2 :
                {
                    R_MAIN_LcdWeightBlink();
                    if(UP_SWITCH_ON == switch_status)
                    {
                        g_Weight = adbcdb(g_Weight, 1U);
                        /* ---- When hour data is 0x24 ---- */
                        if (0x9AU == g_Weight)
                        {
                            g_Weight = 0x00U;
                        }
                    }
                    else if(DOWN_SWITCH_ON == switch_status)
                    {
                        /* ---- When hour data is 0x24 ---- */
                        if (0x00U == g_Weight)
                        {
                            g_Weight = 0x9AU;
                        }
                        g_Weight = sbbcdb(g_Weight, 1U);
                    }
                }
                break;
                
                case 3 :
                {
                    R_MAIN_LcdLengthBlink();
                    if(UP_SWITCH_ON == switch_status)
                    {
                        g_Length = adbcdb(g_Length, 1U);
                        /* ---- When hour data is 0x24 ---- */
                        if (0x9AU == g_Length)
                        {
                            g_Length = 0x00U;
                        }
                    }
                    else if(DOWN_SWITCH_ON == switch_status)
                    {
                        /* ---- When hour data is 0x24 ---- */
                        if (0x00U == g_Length)
                        {
                            g_Length = 0x9AU;
                        
                        }
                        g_Length = sbbcdb(g_Length, 1U);
                    }
                }
                break;
                
                default:
                break;
            }
            if(TRANS_SWITCH_ON == switch_status)
            {
                set_count++;
                if(4U == set_count)
                {
                     set_count = 0U;
                     set_flag = 0U;
                }
            }
        }
    }
}
/***********************************************************************************************************************
End of function main
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_UserInit
* Description  : This function adds user code before implementing main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_UserInit(void)
{
    EI();
    
    R_LCD_Start();
    /* ---- Initialize display ---- */
    memset(LCD_POSITION_MINUTE_LOW, LCD_DATA_NONE, 9U);

    g_WatchStatus = WATCH_DISPLAY;

    R_RTC_Set_ConstPeriodInterruptOn(ONESEC);
    R_RTC_Start();
    R_TAU0_Channel0_Start();
    R_TAU0_Channel1_Start();

    /* Init device ADXL362. */
    ADXL362_Init();
    /* Put the device in standby mode. */
    ADXL362_SetPowerMode(0U);
    /* Set accelerometer's output data rate to: 12.5 Hz. */
    ADXL362_SetOutputRate(ADXL362_ODR_12_5_HZ);
    /* Setup the activity and inactivity detection. */
    ADXL362_SetRegisterValue(
                  ADXL362_ACT_INACT_CTL_LINKLOOP(ADXL362_MODE_LINK),
                  ADXL362_REG_ACT_INACT_CTL,
                  1U);
    ADXL362_SetupActivityDetection(1U, 30U, 1U);
    ADXL362_SetupInactivityDetection(1U, 700U, 25U);
    /* Start the measurement process. */
    ADXL362_SetPowerMode(1U);
    /* Clear ACT and INACT bits by reading the Status Register. */
    ADXL362_GetRegisterValue(&status,
                             ADXL362_REG_STATUS,
                             1U);
}
/***********************************************************************************************************************
End of function R_MAIN_UserInit
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_GetSwitchStatus
* Description  : This function get switch status.
* Arguments    : None
* Return Value : switch_status -The kind of pushed switch
***********************************************************************************************************************/
uint8_t R_MAIN_Get_SwitchStatus(void)
{
    uint8_t set_switch;
    uint8_t up_switch;
    uint8_t down_switch;
    uint8_t trans_switch;

    uint8_t switch_status = SWITCH_ALL_OFF;

    set_switch = P2.1;
    up_switch = P2.0;
    down_switch = P14.4;
    trans_switch = P14.3;

    /* ---- Set switch status ---- */
    if ((0U == set_switch) && (1U == up_switch) && (1U == down_switch) && (1U == trans_switch))
    {
        R_MAIN_Delay1ms(10U);
        set_switch = P2.1;
        up_switch = P2.0;
        down_switch = P14.4;
        trans_switch = P14.3;
        if((0U == set_switch) && (1U == up_switch) && (1U == down_switch) && (1U == trans_switch))
        {
            while(0U == set_switch)
            {
                set_switch = P2.1;
                set_flag  = 1U;
            }
            switch_status = SET_SWITCH_ON;
        }
    }
    else if ((1U == set_switch) && (0U == up_switch) && (1U == down_switch) && (1U == trans_switch))
    {
        R_MAIN_Delay1ms(10U);
        set_switch = P2.1;
        up_switch = P2.0;
        down_switch = P14.4;
        trans_switch = P14.3;
        if((1U == set_switch) && (0U == up_switch) && (1U == down_switch) && (1U == trans_switch))
        {
            while(0U == up_switch)
            {
                up_switch = P2.0;
            }
            switch_status = UP_SWITCH_ON;
        }
    }
    else if ((1U == set_switch) && (1U == up_switch) && (0U == down_switch) && (1U == trans_switch))
    {
        R_MAIN_Delay1ms(10U);
        set_switch = P2.1;
        up_switch = P2.0;
        down_switch = P14.4;
        trans_switch = P14.3;
        if((1U == set_switch) && (1U == up_switch) && (0U == down_switch) && (1U == trans_switch))
        {
            while(0U == down_switch)
            {
                down_switch = P14.4;
            }
            switch_status = DOWN_SWITCH_ON;
        }
    }
    else if ((1U == set_switch) && (1U == up_switch) && (1U == down_switch) && (0U == trans_switch))
    {
        R_MAIN_Delay1ms(10U);
        set_switch = P2.1;
        up_switch = P2.0;
        down_switch = P14.4;
        trans_switch = P14.3;
        if((1U == set_switch) && (1U == up_switch) && (1U == down_switch) && (0U == trans_switch))
        {
            while(0U == trans_switch)
            {
                trans_switch = P14.3;
            }
            switch_status = TRANS_SWITCH_ON;
        }
    }
    else
    {
        /* Do Nothing */
    }
    return (switch_status);
}
/***********************************************************************************************************************
End of function R_MAIN_GetSwitchStatus
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdHourBlink
* Description  : This function hour blink data setup.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdHourBlink(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    NumWork = g_Hour >> 4U;

    if (0U == NumWork)
    {
        NumWork = LCD_DATA_NONE_INDEX;
    }
    else
    {
        /* Do Nothing */
    }

    /* ---- Display tens place of hour data ---- */
    memcpy(LCD_POSITION_HOUR_HIGH, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of hour data ---- */
    NumWork = g_Hour & 0x0FU;
    memcpy(LCD_POSITION_HOUR_LOW, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);

    /* ---- Display colon ---- */
    NumWork = LCD_DATA_COLON_INDEX;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);
    
    disp_data = 0x00U;
    memcpy(&SEG18, &disp_data, 1U);
    /* ---- Display tens place of minute data ---- */
    NumWork = g_Minute >> 4U;
    disp_data = g_FontData[NumWork] * 0x11U;            
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of minute data ---- */
    NumWork = g_Minute & 0x0FU;
    disp_data = g_FontData[NumWork] * 0x11U; 
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdHourBlink
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdMinuteBlink
* Description  : This function minute blink data setup.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdMinuteBlink(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    NumWork = g_Hour >> 4U;

    if (0U == NumWork)
    {
        NumWork = LCD_DATA_NONE_INDEX;
    }
    else
    {
        /* Do Nothing */
    }

    /* ---- Display tens place of hour data ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);

    disp_data = 0x00U;
    memcpy(&SEG18, &disp_data, 1U);
    /* ---- Display ones place of hour data ---- */
    NumWork = g_Hour & 0x0FU;                           /* Get ones place of hour data */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display colon ---- */
    NumWork = LCD_DATA_COLON_INDEX;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);

    /* ---- Display tens place of minute data ---- */
    NumWork = g_Minute >> 4U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of minute data ---- */
    NumWork = g_Minute & 0x0FU;
    memcpy(LCD_POSITION_MINUTE_LOW, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdMinuteBlink
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdWeightBlink
* Description  : This function Weight blink data setup.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdWeightBlink(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork = 0U;

    if (0U == NumWork)
    {
        NumWork = LCD_DATA_NONE_INDEX;
    }
    else
    {
        /* Do Nothing */
    }

    /* ---- Display tens place of hour data ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of hour data ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);

    disp_data = 0x02U * 0x11U;
    memcpy(&SEG18, &disp_data, 1U);

    /* ---- Display colon ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);
    /* ---- Display tens place of minute data ---- */
    NumWork = g_Weight >> 4U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of minute data ---- */
    NumWork = g_Weight & 0x0FU;
    memcpy(LCD_POSITION_MINUTE_LOW, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdWeightBlink
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdLengthBlink
* Description  : This function Length blink data setup.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdLengthBlink(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork = 0U;

    if (0U == NumWork)
    {
        NumWork = LCD_DATA_NONE_INDEX;
    }
    else
    {
        /* Do Nothing */
    }

    /* ---- Display tens place of hour data ---- */
    disp_data = 0x0DU * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of hour data ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);
    
    disp_data = 0x00U * 0x11U;
    memcpy(&SEG18, &disp_data, 1U);
    
    /* ---- Display colon ---- */
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);
    /* ---- Display tens place of minute data ---- */
    NumWork = g_Length >> 4U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of minute data ---- */
    NumWork = g_Length & 0x0FU;
    memcpy(LCD_POSITION_MINUTE_LOW, &g_FontData[NumWork], LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdLengthBlink
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdDisplayNormal
* Description  : This function display time data.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdDisplayNormal(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    NumWork = g_Hour >> 4U;

    if (0U == NumWork)
    {
        NumWork = LCD_DATA_NONE_INDEX;
    }
    else
    {
        /* Do Nothing */
    }

    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of hour data ---- */
    NumWork = g_Hour & 0x0FU;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display colon ---- */
    NumWork = LCD_DATA_COLON_INDEX;
    memcpy(LCD_POSITION_COLON_LOW, &g_FontData[NumWork], LCD_COLON_DATA_SIZE);
    
    disp_data = 0x00U;
    memcpy(&SEG18, &disp_data, 1U);
    
    /* ---- Display tens place of minute data ---- */
    NumWork = g_Minute >> 4U;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);

    /* ---- Display ones place of minute data ---- */
    NumWork = g_Minute & 0x0FU;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdDisplayNormal
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdWeightDisplayNormal
* Description  : This function display Weight data..
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdWeightDisplayNormal(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    /* ---- Display tens place of hour data ---- */
    disp_data = 0x00U;

    /* ---- Display ones place of hour data ---- */
    disp_data = 0x00U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display colon ---- */
    disp_data = 0x00U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);
    
    /* ---- Display tens place of minute data ---- */
    NumWork = g_Weight >> 4U;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of minute data ---- */
    NumWork = g_Weight & 0x0FU;
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdWeightDisplayNormal
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdCalorieDisplayNormal
* Description  : This function display Calorie data.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdCalorieDisplayNormal(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    NumWork = (uint8_t)(g_Calorie >> 12U);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of hour data ---- */
    NumWork = (uint8_t)((g_Calorie >> 8U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display colon ---- */
    disp_data = 0x00U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);

    disp_data = 0x02U * 0x11U;
    memcpy(&SEG18, &disp_data, 1U);
    
    /* ---- Display tens place of minute data ---- */
    NumWork = (uint8_t)((g_Calorie >> 4U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of minute data ---- */
    NumWork = (uint8_t)(g_Calorie & 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdCalorieDisplayNormal
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdStepDisplayNormal
* Description  : This function display step data.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdStepDisplayNormal(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    NumWork = (uint8_t)(g_Step >> 12U);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of hour data ---- */
    NumWork = (uint8_t)((g_Step >> 8U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display colon ---- */
    disp_data = 0x00U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);

    disp_data = 0x01U * 0x11U;
    memcpy(&SEG18, &disp_data, 1U);
    
    /* ---- Display tens place of minute data ---- */
    NumWork = (uint8_t)((g_Step >> 4U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of minute data ---- */
    NumWork =(uint8_t)(g_Step & 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);

}
/***********************************************************************************************************************
End of function R_MAIN_LcdStepDisplayNormal
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_LcdStepDisplayNormal
* Description  : This function display last day step data.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_LcdLastStepDisplayNormal(void)
{
    uint16_t disp_data;
    uint8_t *tmp;
    uint8_t NumWork;

    /* ---- Display tens place of hour data ---- */
    NumWork = (uint8_t)(g_Step_last >> 12U);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of hour data ---- */
    NumWork = (uint8_t)((g_Step_last >> 8U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_HOUR_LOW, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display colon ---- */
    disp_data = 0x00U;
    memcpy(LCD_POSITION_COLON_LOW, &disp_data, LCD_COLON_DATA_SIZE);

    disp_data = 0x04U * 0x11U;
    memcpy(&SEG18, &disp_data, 1U);
    
    /* ---- Display tens place of minute data ---- */
    NumWork = (uint8_t)((g_Step_last >> 4U)& 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_HIGH, &disp_data, LCD_NUM_DATA_SIZE);
  
    /* ---- Display ones place of minute data ---- */
    NumWork = (uint8_t)(g_Step_last & 0x0FU);
    disp_data = g_FontData[NumWork] * 0x11U;
    memcpy(LCD_POSITION_MINUTE_LOW, &disp_data, LCD_NUM_DATA_SIZE);
}
/***********************************************************************************************************************
End of function R_MAIN_LcdLastStepDisplayNormal
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: Write_DataFlash
* Description  : This function Write two bytes to Data Flash.
* Arguments    : None
* Return Value : TRUE       Write successful
*                FALSE      Write fail
***********************************************************************************************************************/
pfdl_u08 Write_DataFlash(void)
{
    pfdl_status_t my_status_enu;
    __near pfdl_descriptor_t descriptor_user;
    __near pfdl_request_t request;
    
    descriptor_user.fx_MHz_u08 = 1U;
    descriptor_user.wide_voltage_mode_u08 = 0x01U;

    my_status_enu = PFDL_Open(&descriptor_user);
    
    if(my_status_enu == PFDL_OK)
    {
        request.index_u16 = StartAddrIndex;
        request.data_pu08 = g_Step_temp1;
        request.bytecount_u16 = 0x02U;
        request.command_enu = PFDL_CMD_WRITE_BYTES;
        my_status_enu = PFDL_Execute(&request);
        while(my_status_enu == PFDL_BUSY)
            my_status_enu = PFDL_Handler();
        if(my_status_enu == PFDL_OK)
        {
            PFDL_Close();
            return TRUE;
        }
        else
            return FALSE;
    }
    else
        return TRUE;
}
/***********************************************************************************************************************
End of function Write_DataFlash
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: Read_DataFlash
* Description  : This function Read two bytes from Data Flash.
* Arguments    : None
* Return Value : TRUE       Write successful
*                FALSE      Write fail
***********************************************************************************************************************/
pfdl_u08 Read_DataFlash(void)
{
    pfdl_status_t my_status_enu;
    __near pfdl_descriptor_t descriptor_user;
    __near pfdl_request_t request;
    
    descriptor_user.fx_MHz_u08 = 1U;
    descriptor_user.wide_voltage_mode_u08 = 0x01U;
    
    my_status_enu = PFDL_Open(&descriptor_user);
    
    if(my_status_enu == PFDL_OK)
    {
        request.index_u16 = StartAddrIndex;
        request.data_pu08 = g_Step_temp2;
        request.bytecount_u16 = 0x02U;
        request.command_enu = PFDL_CMD_READ_BYTES;
        my_status_enu = PFDL_Execute(&request);
        while(my_status_enu == PFDL_BUSY)
            my_status_enu = PFDL_Handler();
        if(my_status_enu == PFDL_OK)
        {
            PFDL_Close();
            return TRUE;
        }
        else
            return FALSE;
    }
    else
        return TRUE;
}
/***********************************************************************************************************************
End of function Read_DataFlash
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: Erase_DataFlash
* Description  : This function Erase 1 block of Data Flash
* Arguments    : block      block number of the block to be erased
* Return Value : TRUE       Erase successful
*                FALSE      Erase fail
***********************************************************************************************************************/
pfdl_u08 Erase_DataFlash(pfdl_u16 block)
{
    pfdl_status_t my_status_enu;
    __near pfdl_descriptor_t descriptor_user;
    __near pfdl_request_t request;

    descriptor_user.fx_MHz_u08 = 1U;
    descriptor_user.wide_voltage_mode_u08 = 0x01U;

    my_status_enu = PFDL_Open(&descriptor_user);
    
    if(my_status_enu == PFDL_OK)
    {
        request.index_u16 = block;
        request.command_enu = PFDL_CMD_ERASE_BLOCK;
        my_status_enu = PFDL_Execute(&request);
        while(my_status_enu == PFDL_BUSY)
            my_status_enu = PFDL_Handler();
        if(my_status_enu == PFDL_OK)
        {
            PFDL_Close();
            return TRUE;
        }
        else
            return FALSE;
    }
    else
        return FALSE;
}
/***********************************************************************************************************************
End of function Erase_DataFlash
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_MAIN_Delay1ms
* Description  : This function delays 1ms using software
* Arguments    : time
* Return Value : None
***********************************************************************************************************************/
void R_MAIN_Delay1ms(uint8_t time)
{
    uint8_t i;
    uint16_t j;
    
    for (i = 0U; i < time; i++)
    {
        for (j = 0U; j < 200U; j++);
    }
}
/***********************************************************************************************************************
* End of function R_MAIN_Delay1ms
***********************************************************************************************************************/